# Cài kỹ năng video-hoc-thuat

Chép thư mục video-hoc-thuat vào .agents/skills/ trong dự án hỗ trợ cơ chế này, hoặc thư mục kỹ năng do môi trường quy định. Giữ nguyên SKILL.md, references, scripts và template.

Nếu cần, thêm quy tắc trong AGENTS.example.md vào AGENTS.md hiện có; không ghi đè nội dung cũ. Làm mới phiên nếu môi trường cần nạp lại kỹ năng.

Cách gọi: Dùng $video-hoc-thuat để tạo video học thuật từ tài liệu này.

Nếu cuộc trò chuyện không hỗ trợ cài kỹ năng hoặc không truy cập kho, đính kèm gói này và yêu cầu đọc SKILL.md. Gói không tự cài vào toàn bộ tài khoản.
