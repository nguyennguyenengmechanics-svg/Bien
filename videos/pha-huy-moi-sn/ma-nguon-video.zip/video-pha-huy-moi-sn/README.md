# Video phá hủy mỏi và đường cong S–N

1080×1920, 30 fps, 231,008 giây. HTML/SVG + GSAP, giọng Việt tổng hợp và nhạc riêng. Từ khóa dùng strong/em; chữ nằm trong span để giữ dòng văn bản tự nhiên trong vùng flex.

Mở thư mục này bằng HyperFrames CLI 0.9.0:

```sh
npx hyperframes preview
npx hyperframes lint
npx hyperframes check --samples 12
npx hyperframes render . --output pha-huy-moi-duong-cong-sn.mp4 --fps 30 --quality high
```

Nếu dùng Chromium cài sẵn: đặt HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium. Mọi tài nguyên phát lại cần thiết có trong assets. Không cần tải mô hình TTS để render lại. Lời dẫn, phụ đề, ghi chú kỹ thuật và giấy phép có trong gói. Đồ thị chỉ minh họa.
