import json,pathlib,html,shutil,math
R=pathlib.Path(__file__).parent; P=R/'composition'
scenes=json.loads((R/'timing.json').read_text())
E=html.escape
import re
def rich(value, words):
 escaped=E(value)
 chosen=[w for w in sorted(words,key=len,reverse=True) if w.casefold() in value.casefold()][:2]
 if not chosen:return escaped
 rx=re.compile('|'.join(re.escape(E(w)) for w in chosen),re.I)
 return rx.sub(lambda m:'<strong class="em">'+m.group(0)+'</strong>',escaped)

ink='#142D38';red='#B83B16';green='#2D6842';pale='#E5E7DE'
def text(x,y,s,size=30,color=ink,anchor='middle',bold=False,cls=''):
 size=max(size,28)
 return f'<text class="{cls}" x="{x}" y="{y}" fill="{color}" text-anchor="{anchor}" font-family="DejaVu Sans" font-size="{size}" font-weight="{700 if bold else 400}">{E(s)}</text>'
def line(x1,y1,x2,y2,color=ink,w=5,extra=''):
 return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="{w}" {extra}/>'
def rect(x,y,w,h,fill=pale,stroke=ink,rx=10,extra=''):
 return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="4" {extra}/>'
def path(d,color=ink,w=6,fill='none',extra=''):
 return f'<path d="{d}" stroke="{color}" stroke-width="{w}" fill="{fill}" stroke-linecap="round" stroke-linejoin="round" {extra}/>'
def arrow(x1,y1,x2,y2,idx,color=red):
 return line(x1,y1,x2,y2,color,6,f'marker-end="url(#a{idx})" class="force"')
def support(x,y):
 return path(f'M{x-35} {y+30} L{x} {y} L{x+35} {y+30} Z',ink,4,pale)+line(x-45,y+40,x+45,y+40,ink,4)
def labelbox(x,y,w,s,color=ink):
 return rect(x,y,w,54,'#F1F0E4','none',10)+text(x+w/2,y+36,s,25,color,bold=True)
blue='#0A527B'
def svg(kind,i):
 a=f'<svg viewBox="0 0 900 570"><defs><marker id="a{i}" markerWidth="22" markerHeight="22" refX="20" refY="11" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,22 L22,11 z" fill="{red}"/></marker><marker id="b{i}" markerWidth="22" markerHeight="22" refX="20" refY="11" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,22 L22,11 z" fill="{blue}"/></marker></defs>'
 def branch(x1,y1,x2,y2,c=blue,cls='branch'):
  return line(x1,y1,x2,y2,c,9,f'marker-end="url(#{"b" if c==blue else "a"}{i})" class="{cls}"')
 def card(x,y,w,h,title,sub='',color=blue,cls='node'):
  bg='#E1EFF6' if color==blue else ('#FFE1BD' if color==red else '#E3EFE4')
  return f'<g class="{cls}">'+rect(x,y,w,h,bg,color,12)+rect(x,y,11,h,color,'none',3)+text(x+w/2,y+44,title,30,color,bold=True)+(text(x+w/2,y+87,sub,28,ink) if sub else '')+'</g>'
 def wave(x0,x1,y,amp,period=150):
  return 'M'+' L'.join(f'{x:.2f} {y-amp*math.sin((x-x0)*2*math.pi/period):.2f}' for x in range(int(x0),int(x1)+1,4))
 def chart(guides=False,footer=True):
  o=text(130,65,'S = σa (MPa)',29,blue,'start',True)+text(690,65,'N: thang log',29,blue,bold=True)
  o+=line(130,430,805,430,ink,5)+line(130,430,130,95,ink,5)
  for x,t in [(160,'10³'),(300,'10⁴'),(440,'10⁵'),(580,'10⁶'),(720,'10⁷')]:o+=line(x,430,x,444,ink,4)+text(x,477,t,28,ink,bold=True)
  for y,t in [(130,'100'),(280,'50')]:o+=line(115,y,130,y,ink,4)+text(102,y+10,t,28,ink,'end')
  o+=text(805,477,'N',28,blue,bold=True)
  o+=path('M160 110 C220 145 265 175 300 190 C350 220 405 245 440 255 C480 268 515 277 537.86 280 C590 294 655 318 720 335',blue,8,extra='class="sncurve"')
  if guides:
   o+=line(130,280,537.86,280,red,6,'stroke-dasharray="12 8" class="read-guide"')+line(537.86,280,537.86,430,red,6,'stroke-dasharray="12 8" class="read-guide"')+f'<circle class="read-dot" cx="537.86" cy="280" r="12" fill="{red}" stroke="#FFFFFF" stroke-width="4"/>'
  if footer:o+=text(450,550,'Đồ thị minh họa, không phải dữ liệu vật liệu',26,red,bold=True)
  return o
 if kind=='intro':
  a+=text(450,55,'KHÔNG CHỈ LÀ MỘT LẦN QUÁ TẢI',31,red,bold=True)
  a+=path('M165 165 H425 L450 195 L475 165 H735 V290 H165 Z',ink,5,'#CEDBDD',extra='class="part"')
  a+=path('M450 195 l-15 20 24 15 -20 19 17 22 -9 19',red,9,extra='class="growing-crack"')
  a+=arrow(150,225,60,225,i)+arrow(750,225,840,225,i)
  a+=path(wave(140,760,405,45,130),red,7,extra='class="loadwave"')+text(450,510,'TẢI LẶP → NGUY CƠ HƯ HẠI TÍCH LŨY',29,red,bold=True)+text(450,555,'Chu kỳ và vết nứt chỉ minh họa, không định lượng',24,ink)
 elif kind=='stages':
  for j,(x,t,c) in enumerate([(45,'1. KHỞI TẠO',red),(335,'2. LAN NỨT',blue),(625,'3. GÃY CUỐI',red)]):a+=card(x,60,230,100,t,color=c)
  a+=branch(280,110,320,110,blue)+branch(570,110,610,110,red)
  for j,x in enumerate([55,345]):
   a+=rect(x,240,220,145,'#CEDBDD',ink,8)
   d=f'M{x+105} 240 l-12 20 18 12 -16 22'+(' l20 15 -18 25 16 25' if j else '')
   a+=path(d,red,8,extra=f'class="stage-crack stage{j}"')
  a+=path('M635 240 H745 L735 270 755 290 737 320 753 350 740 385 H635 Z',ink,5,'#CEDBDD',extra='class="broken-left"')+path('M745 240 H845 V385 H740 L753 350 737 320 755 290 735 270 Z',ink,5,'#CEDBDD',extra='class="broken-right"')
  a+=text(450,470,'Nứt có thể phát triển trước khi ta nhìn thấy',29,red,bold=True)+text(450,535,'Bo góc và chất lượng bề mặt rất đáng chú ý',28,green,bold=True)
 elif kind=='cycle':
  a+=text(450,55,'ĐẢO CHIỀU HOÀN TOÀN · R = −1',29,blue,bold=True)
  a+=line(125,100,125,315,ink,5)+line(125,315,790,315,ink,5)+line(125,200,790,200,blue,3,'stroke-dasharray="10 8"')
  a+=path(wave(140,755,200,75,180),red,8,extra='class="cyclewave"')+text(85,112,'σ',32,ink,bold=True)+text(790,350,'t',30,ink,bold=True)
  a+=text(740,100,'+50 MPa',29,red,'end',True)+text(740,305,'−50 MPa',29,red,'end',True)+text(90,210,'0',28,blue,'end')
  a+=text(450,405,'Δσ = 100 MPa',44,red,bold=True)+text(450,470,'σa = 50 MPa',44,blue,bold=True)+text(450,540,'σm = 0',42,ink,bold=True)
 elif kind=='sn':a+=chart()
 elif kind=='read':
  a+=chart(True,False)+card(85,495,730,70,'500.000 phút ≈ 347 ngày',color=red,cls='timecard')
 elif kind=='limit':
  a+=text(450,55,'HAI DẠNG ĐƯỜNG ĐỊNH TÍNH',29,blue,bold=True)+line(130,430,805,430,ink,5)+line(130,430,130,100,ink,5)+text(90,115,'S',32,ink,bold=True)+text(800,470,'N (log)',28,blue,'end',True)
  a+=path('M170 140 C280 210 340 260 450 290 C540 300 640 300 760 300',green,9,extra='class="limitcurve"')+path('M170 170 C340 265 500 330 760 390',blue,9,extra='class="nolimitcurve"')
  a+=text(610,250,'Có vùng gần ngang',28,green,bold=True)+text(490,410,'Không mặc định có giới hạn',28,blue,bold=True)
  a+=text(450,545,'“Vĩnh viễn” không phải bảo đảm cho chi tiết thực',27,red,bold=True)
 elif kind=='scatter':
  a+=text(450,55,'DỮ LIỆU MỎI CÓ PHÂN TÁN',30,red,bold=True)+line(130,430,805,430,ink,5)+line(130,430,130,100,ink,5)+text(90,115,'S',32,ink,bold=True)+text(800,470,'N (log)',28,blue,'end',True)
  a+=path('M165 130 C330 225 480 280 750 335','#657A80',6,extra='stroke-dasharray="12 10"')+path('M165 195 C330 285 480 340 750 395',blue,9,extra='class="designcurve"')
  for x,y in [(200,155),(245,188),(280,165),(340,230),(385,214),(415,245),(500,285),(560,273),(610,305),(690,322)]:a+=f'<circle class="sample-point" cx="{x}" cy="{y}" r="9" fill="{red}" stroke="#FFFFFF" stroke-width="3"/>'
  a+=text(640,245,'Đường đại diện',28,'#52666D',bold=True)+text(605,425,'Đường thiết kế',28,blue,bold=True)+text(450,550,'Minh họa phân tán · Không gán xác suất cụ thể',25,red,bold=True)
 elif kind=='methods':
  a+=card(175,45,550,95,'BIẾN DẠNG CHU KỲ',color=ink)
  a+=path('M450 145 V195 H240 V235',blue,9,extra='class="method-branch"')+path('M450 195 H660 V235',red,9,extra='class="method-branch"')
  a+=card(55,245,370,250,'HCF',color=blue)+card(475,245,370,250,'LCF',color=red)
  a+=text(240,350,'CHỦ YẾU ĐÀN HỒI',28,blue,bold=True)+text(660,350,'DẺO CHU KỲ ĐÁNG KỂ',27,red,bold=True)+text(240,445,'S–N',61,blue,bold=True)+text(660,420,'Biến dạng',37,red,bold=True)+text(660,465,'– tuổi thọ',37,red,bold=True)
  a+=text(450,550,'Không chỉ nhìn một ngưỡng số chu kỳ',29,green,bold=True)
 elif kind=='goodman':
  a+=text(245,50,'CÙNG BIÊN ĐỘ',28,blue,bold=True)+text(665,50,'KHÁC TRUNG BÌNH',28,red,bold=True)
  a+=line(100,140,385,140,blue,3,'stroke-dasharray="8 7"')+line(510,140,795,140,blue,3,'stroke-dasharray="8 7"')+path(wave(110,375,140,30,100),blue,6)+path(wave(520,785,105,30,100),red,6)
  a+=text(245,215,'σm = 0',32,blue,bold=True)+text(665,215,'σm > 0',32,red,bold=True)
  a+=line(200,470,765,470,ink,5)+line(200,470,200,275,ink,5)+path('M200 280 L740 470',blue,8,extra='class="goodman-line"')+text(155,265,'σa',30,ink,bold=True)+text(785,490,'σm',30,ink,bold=True)
  a+=line(300,350,550,350,red,4,'stroke-dasharray="10 8"')+f'<circle class="meanpoint" cx="300" cy="350" r="12" fill="{red}"/>'
  a+=text(235,275,'Se',28,blue,bold=True)+text(735,510,'Sut',28,blue,bold=True)+text(450,560,'σa/Se + σm/Sut ≤ 1  (mô hình)',31,red,bold=True)
 elif kind=='miner':
  a+=text(450,50,'LỊCH SỬ TẢI BIẾN THIÊN',29,blue,bold=True)
  d='M'+' L'.join(f'{x} {130-35*math.sin(x*.04)-20*math.sin(x*.095):.2f}' for x in range(100,801,5));a+=path(d,red,6)
  a+=card(325,215,250,75,'Rainflow',color=blue)+path('M450 295 V315 H250 V330 M450 315 H650 V330',blue,9)
  a+=card(65,340,365,110,'20.000 / 100.000','0,2',blue)+card(475,340,365,110,'100.000 / 500.000','0,2',blue)
  a+=text(450,515,'D = 0,2 + 0,2 = 0,4',45,red,bold=True,cls='damage')+text(450,560,'Nhóm tải giả định, không phải kết quả đếm từ hình',24,ink)
 elif kind=='cracked':
  a+=text(450,55,'ĐÃ CÓ VẾT NỨT: XÉT TUỔI THỌ CÒN LẠI',26,red,bold=True)
  a+=rect(155,155,590,145,'#CEDBDD',ink,7)+path('M435 155 l-14 20 24 15 -20 19 16 22 -11 24 18 20 -10 25',red,9,extra='class="existing-crack"')
  a+=text(280,125,'a₀ đã biết',30,blue,bold=True)+path('M450 305 V340 H235 V380 M450 340 H665 V380',blue,9)
  a+=card(55,385,370,120,'CƠ HỌC PHÁ HỦY','Đúng miền áp dụng',blue)+card(475,385,370,120,'KIỂM TRA NỨT','Khả năng phát hiện',green)
  a+=text(450,560,'Không thay bằng S–N mẫu trơn một cách trực tiếp',25,red,bold=True)
 else:
  for j,(t,sub,c) in enumerate([('PHỔ TẢI','Biên độ · trung bình',blue),('HÌNH HỌC','Giảm tập trung ứng suất',red),('DỮ LIỆU','Đúng điều kiện',blue),('BỀ MẶT','Gia công · môi trường',green),('VẾT NỨT','Phát hiện · theo dõi',red),('KIỂM CHỨNG','Độ tin cậy · tiêu chuẩn',green)]):
   x=55+j%2*420;y=35+j//2*170;a+=card(x,y,370,135,t,sub,c)
  a+=text(450,555,'Bền tĩnh ≠ đã kiểm tra đủ mỏi',33,red,bold=True)
 return a+'</svg>'

css='''.em{font-weight:700;color:#A82F0D;background:#FFE1BD;padding:1px 5px;border-radius:5px}.headline .em{background:none;padding:0;color:#B83B16}.growing-crack,.stage-crack,.existing-crack{stroke-dasharray:300;stroke-dashoffset:0}.caption strong{font-weight:700}@font-face{font-family:"DejaVu Serif";src:url(assets/DejaVuSerif-Bold.ttf);font-weight:700}@font-face{font-family:"DejaVu Sans";src:url(assets/DejaVuSans.ttf);font-weight:400}@font-face{font-family:"DejaVu Sans";src:url(assets/DejaVuSans-Bold.ttf);font-weight:700}*{box-sizing:border-box}html,body{margin:0;width:1080px;height:1920px;overflow:hidden;background:#F1F0E4;color:#142D38;font-family:"DejaVu Sans",sans-serif}#root{width:1080px;height:1920px;position:relative}.scene{position:absolute;inset:0;width:1080px;height:1920px;background:#F1F0E4;overflow:hidden}.scene-content{width:100%;height:100%;padding:90px 80px 110px;display:flex;flex-direction:column;gap:25px}.brand{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #142D3840;padding-bottom:24px;font-size:28px;letter-spacing:3px;font-weight:700}.brand span:last-child{color:#B83B16;letter-spacing:1px}.kicker{font-size:28px;color:#B83B16;font-weight:700;letter-spacing:2px;margin-top:16px}.headline{font-family:"DejaVu Serif",serif;font-size:78px;font-weight:700;line-height:1.16;letter-spacing:-3px;white-space:pre-line;margin:0;min-height:200px;display:flex;align-items:center}.key{font-size:31px;font-weight:700;color:#0A527B;line-height:1.3;min-height:80px;display:flex;align-items:center}.figure{height:680px;flex-shrink:0;background:#FFFFFF;border:2px solid #142D3818;border-radius:22px;box-shadow:0 12px 30px #142D3809;overflow:hidden}.figure svg{width:100%;height:100%;display:block}.rule{border-left:8px solid #2D6842;background:#E5E7DE;padding:24px 27px;border-radius:0 15px 15px 0;min-height:130px;display:flex;flex-direction:column;justify-content:center;gap:12px}.rule-label{font-size:28px;letter-spacing:2px;color:#2D6842;font-weight:700}.rule-text{font-size:30px;line-height:1.4;font-weight:700}.caption-zone{height:188px;position:relative;margin-top:8px;flex-shrink:0}.caption{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;line-height:1.5;font-size:36px;color:#142D38;font-weight:400;padding:5px 8px}.foot{margin-top:auto;display:flex;justify-content:space-between;font-size:28px;color:#2D6842;gap:10px;line-height:1.5}.progress{position:absolute;bottom:55px;left:80px;width:920px;height:5px;background:#142D3815}.progress-fill{height:100%;background:#B83B16;transform-origin:left}.force{transform-box:fill-box;transform-origin:center}.crack{stroke-dasharray:240;stroke-dashoffset:0}.hotspot{transform-origin:center;transform-box:fill-box}'''
parts=['<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><title>Phá hủy mỏi và đường cong S–N</title><script src="assets/gsap.min.js"></script><style>'+css+'</style></head><body>']
total=round(scenes[-1]['start']+scenes[-1]['duration'],3)
parts+=[f'<div id="root" data-composition-id="main" data-width="1080" data-height="1920" data-start="0" data-duration="{total}">']
anims=[];srt=[];ci=0
for i,s in enumerate(scenes):
 ident=f's{i}';start=s['start'];duration=s['duration']
 caps=''
 for j,seg in enumerate(s['segments']):
  caps+=f'<div id="cap{i}-{j}" class="caption" style="opacity:0"><span>{rich(seg["text"],s.get("highlights",[]))}</span></div>'
  anims += [f'tl.to("#cap{i}-{j}",{{opacity:1,duration:.13}}, {seg["start"]});',f'tl.to("#cap{i}-{j}",{{opacity:0,duration:.13}}, {seg["start"]+seg["duration"]+.12});']
  ci+=1
  def stamp(t):
   ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
  srt.append(f'{ci}\n{stamp(seg["start"])} --> {stamp(seg["start"]+seg["duration"])}\n{seg["text"]}\n')
 foot='Sơ đồ nguyên lý · Không phải mô phỏng' if i not in [0,10,11] else 'Tổng hợp từ báo cáo kỹ thuật được cung cấp'
 parts += [f'<section class="scene" data-layout-allow-overflow id="{ident}" style="opacity:{1 if i==0 else 0};z-index:{i+1}"><div class="scene-content"><div class="brand"><span>PHÁ HỦY MỎI</span><span>{i+1:02} / 12</span></div><div class="kicker">{E(s["tag"])}</div><h1 class="headline"><span>{rich(s["title"],s.get("title_em",[]))}</span></h1><div class="key">{E(s["key"])}</div><div class="figure">{svg(s["diagram"],i)}</div><div class="rule"><div class="rule-label">'+('NGUYÊN TẮC ÁP DỤNG' if 1<=i<=10 else 'GHI NHỚ')+f'</div><div class="rule-text">{E(s["rule"])}</div></div><div class="caption-zone">{caps}</div><div class="foot"><span>{foot}</span><span>{i+1:02}</span></div></div></section>']
 if i:
  anims += [f'tl.to("#s{i-1}",{{x:-1080,duration:.45,ease:"power3.inOut"}},{start});',f'tl.set("#s{i-1}",{{opacity:0}},{start+.45});']
  anims += [f'tl.fromTo("#{ident}",{{x:1080,opacity:1}},{{x:0,opacity:1,duration:.45,ease:"power3.inOut",immediateRender:false}},{start});']
 anims += [f'tl.from("#{ident} .brand",{{y:-12,opacity:0,duration:.45,ease:"power2.out"}},{start+.12});',f'tl.from("#{ident} .kicker",{{x:-25,opacity:0,duration:.45,ease:"power3.out"}},{start+.18});',f'tl.from("#{ident} .headline",{{y:35,opacity:0,duration:.65,ease:"power3.out"}},{start+.25});',f'tl.from("#{ident} .key",{{x:25,opacity:0,duration:.6,ease:"sine.out"}},{start+.4});',f'tl.from("#{ident} .figure",{{scale:.96,opacity:0,duration:.65,ease:"power2.out"}},{start+.5});',f'tl.from("#{ident} .rule",{{y:24,opacity:0,duration:.6,ease:"back.out(1.05)"}},{start+1.1});',f'tl.from("#{ident} .foot",{{opacity:0,duration:.5,ease:"sine.out"}},{start+.6});']
 k=s['diagram'];at=start+2.4
 if k=='intro':
  anims +=[f'tl.to("#{ident} .part",{{rotation:1.1,svgOrigin:"450 225",duration:.6,repeat:9,yoyo:true,ease:"sine.inOut"}},{at});',f'tl.from("#{ident} .growing-crack",{{strokeDashoffset:300,duration:7,ease:"power1.in"}},{at});']
 if k=='stages':
  anims +=[f'tl.from("#{ident} .stage-crack",{{strokeDashoffset:300,stagger:2,duration:2,ease:"power2.out"}},{at});',f'tl.to("#{ident} .broken-left",{{x:-10,duration:.7,ease:"power2.out"}},{at+5});',f'tl.to("#{ident} .broken-right",{{x:10,duration:.7,ease:"power2.out"}},{at+5});']
 if k in ['cycle','sn','read','limit','scatter','goodman','miner','cracked']:
  target={'cycle':'cyclewave','sn':'sncurve','read':'sncurve','limit':'limitcurve','scatter':'designcurve','goodman':'goodman-line','miner':'damage','cracked':'existing-crack'}[k]
  anims +=[f'tl.from("#{ident} .{target}",{{opacity:0,duration:1.1,ease:"sine.out"}},{at});']
 if k=='read':anims +=[f'tl.from("#{ident} .read-guide",{{scaleY:0,transformOrigin:"top",stagger:.5,duration:1,ease:"power2.out"}},{at});',f'tl.from("#{ident} .read-dot",{{scale:.1,transformOrigin:"center",duration:.6,ease:"back.out(1.2)"}},{at+1});']
 if k=='scatter':anims +=[f'tl.from("#{ident} .sample-point",{{scale:.1,transformOrigin:"center",stagger:.15,duration:.5,ease:"power2.out"}},{at});']
 if k=='goodman':anims +=[f'tl.to("#{ident} .meanpoint",{{x:250,duration:2.6,ease:"power2.inOut"}},{at+1});']
 if k in ['stages','methods','miner','cracked','closing']:
  anims +=[f'tl.from("#{ident} .node",{{y:18,opacity:0,stagger:.23,duration:.6,ease:"power3.out"}},{start+1.2});']
 if k=='miner':anims +=[f'tl.from("#{ident} .damage",{{scale:.92,transformOrigin:"center",duration:.8,ease:"power2.out",immediateRender:false}},{s['segments'][1]['start']});']
parts +=[f'<div class="progress"><div id="progress" class="progress-fill"></div></div><audio id="voiceover" src="assets/narration.wav" data-start="0" data-duration="{total}" data-track-index="2" data-volume="1"></audio><audio id="music" src="assets/music.wav" data-start="0" data-duration="{total}" data-track-index="3" data-volume="1"></audio></div>']
# progress belongs above all scenes
anims=[a for a in anims if 'tl.from("#s0 .headline"' not in a]
parts += ['<style>.progress{z-index:50}</style><script>window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});'+ '\n'.join(anims)+f'\ntl.from("#progress",{{scaleX:0,duration:{total},ease:"none"}},0);\nwindow.__timelines.main=tl;</script></body></html>']
(P/'index.html').write_text(''.join(parts));(R/'output/phu-de.vi.srt').write_text('\n'.join(srt))
(R/'output/loi-dan.txt').write_text('\n\n'.join(s['tag']+'\n'+' '.join(s['voice']) for s in scenes))
# narration is normalized separately after source generation
print('Built',total,'seconds')
