# Visual identity — Phá hủy mỏi và S–N: nhấn mạnh để hiểu
## Style Prompt
Continue the user's cream engineering explainer series, with the user's explicit new preference for much stronger emphasis. Large animated mechanical drawings and charts. Bold colored keywords in headlines, captions and numbered branches. Orange indicates crack, load and cautions; saturated blue identifies cycle counts, data and analysis; dark green indicates prevention. Thick connector branches, legible phone-size labels, one or two hot phrases per caption. All plotted curves are explicitly schematic unless values are identified as hypothetical examples.
## Colors
- #F1F0E4: cream canvas
- #142D38: ink and structure
- #B83B16: strong orange, risk and keyword emphasis
- #0A527B: saturated blue, data, cycles and analysis
- #2D6842: dark green, prevention
- #FFE1BD: pale orange keyword background
- #FFFFFF: diagram cards
## Typography
DejaVu Serif Bold for display headings; DejaVu Sans regular for narration captions, Bold for meaningful keywords, equations, numbers and branch titles. Display 78 px; captions 36 px; diagram reading labels at least 28 px in the 900-unit SVG.
## Motion
Seekable paused GSAP timeline. Clear page transitions, finite repeated stress cycles, progressive crack drawing, staged S–N guides and arithmetic. Entrance animations lead the eye. Diagrams stay visible during speech. No decorative jitter or fast flashing.
## What NOT to Do
- Do not make entire captions bold or assign a different color to each word.
- Do not call an illustrative curve measured data or a guarantee of infinite life.
- Do not confuse stress amplitude and stress range.
- Do not claim a fixed standard-deviation shift universally gives 1% failure probability.
- No robots, unrelated stock imagery or tiny dense paragraphs.
