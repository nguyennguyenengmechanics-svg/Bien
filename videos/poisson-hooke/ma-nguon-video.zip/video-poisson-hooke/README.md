# Hệ số Poisson và định luật Hooke tổng quát

Nguồn chỉnh sửa: index.html. Font, giọng đọc và nhạc kèm assets. Cần Node.js 22+, Chromium và FFmpeg; không cần API key để xuất lại.

```bash
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 render --output final.mp4 --fps 30 --quality high --workers 3
```

Đọc GHI-CHU.txt về nguồn, giả thiết kỹ thuật và attribution. Số liệu ví dụ là giả định minh họa; các khối co–nở chỉ minh họa nguyên lý có phóng đại, không phải mô phỏng số.
