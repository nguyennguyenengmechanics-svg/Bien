# Visual identity — Hệ số Poisson và Hooke tổng quát
## Style Prompt
An editorial engineering field guide inspired by the user's cream infographic reference. Warm drafting paper, oversized serif questions, precise sans-serif labels, ink-blue mechanical diagrams, terracotta decision emphasis, olive prevention cards. Each diagram is a conceptual schematic, not a simulation. Larger animated diagrams occupy the center: bars stretch and contract laterally, three response types compare, cubes deform, and stress contributions build formulas. One governing idea and one engineering action per chapter. Vertical 1080 × 1920, legible on a phone, generous safe margins, quiet confident motion.
## Colors
- #F1F0E4: warm paper canvas
- #182E35: ink and structural outlines
- #B54F30: risk, change and emphasis
- #52653F: prevention and verified actions
- #FFFFFF: diagram and information cards
## Typography
DejaVu Serif Bold for short display statements; DejaVu Sans for engineering labels, subtitles and explanations. Serif is the editorial narrator; sans is the drawing annotation.
## Motion
Staggered entrances, 0.4 s page transitions, synchronized atomic bonds, qualitative energy wells, beam deflection and sectional comparisons illustrate mechanics. Gentle finite cycles, no flashy unrelated effects. Fully visible text held during narration.
## What NOT to Do
- No stock robot imagery or decorative machinery unrelated to the mechanism.
- No equations presented as a complete design check.
- No generic glowing tech background.
- No tiny dense paragraphs or subtitles over the diagram.
- No implication these conceptual drawings are numerical simulations.
