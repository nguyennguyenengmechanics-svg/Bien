blue='#0A527B'
def svg(kind,i):
 a=f'<svg viewBox="0 0 900 570"><defs>'
 for key,c in [('a',red),('b',blue)]:a+=f'<marker id="{key}{i}" markerWidth="20" markerHeight="20" refX="18" refY="10" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,20 L20,10 z" fill="{c}"/></marker>'
 a+='</defs>'
 def ar(x1,y1,x2,y2,c=blue):return line(x1,y1,x2,y2,c,7,f'marker-end="url(#{"b" if c==blue else "a"}{i})"')
 def card(x,y,w,h,title,sub='',c=blue):
  return '<g class="node">'+rect(x,y,w,h,'#E1EFF6' if c==blue else '#FFE1BD',c,10)+rect(x,y,10,h,c,'none',2)+text(x+w/2,y+42,title,31,c,bold=True)+(text(x+w/2,y+85,sub,28)if sub else '')+'</g>'
 def branch(x1,y1,x2,y2,c=blue):return line(x1,y1,x2,y2,c,9)
 def note(s):return text(450,545,s,28,green,bold=True)
 def plate(hole=False):
  out=path('M200 360 H700 L725 385 H225 Z',blue,4,'#B9CED7')+path('M700 120 L725 145 V385 L700 360 Z',blue,4,'#C9DAE1')+rect(200,120,500,240,'#E1EFF6',blue,0)
  if hole:out+=f'<circle cx="450" cy="240" r="68" fill="white" stroke="{blue}" stroke-width="5"/>'
  return out
 if kind=='intro':
  a+=text(450,50,'ỨNG SUẤT TRONG MẶT PHẲNG x–y',30,blue,bold=True)+plate()
  a+=ar(190,240,65,240)+ar(735,240,855,240)+ar(450,110,450,65)+ar(450,395,450,450)
  a+=text(120,208,'σx',34,blue,bold=True)+text(805,208,'σx',34,blue,bold=True)+text(505,90,'σy',34,blue,bold=True)
  a+=line(770,350,770,390,red,5)+text(800,380,'t',32,red,bold=True)+note('z theo chiều dày · Hình học chỉ minh họa')
 elif kind=='tensor':
  a+=text(450,50,'σz = τxz = τyz = 0',40,red,bold=True)
  vals=[['σx','τxy','0'],['τxy','σy','0'],['0','0','0']]
  for row in range(3):
   for col in range(3):
    v=vals[row][col];c=blue if v!='0' else red
    a+='<g class="'+('zero'if v=='0'else'entry')+'">'+rect(200+col*170,95+row*110,165,105,'#E1EFF6'if v!='0'else'#FFE1BD','white',0)+text(282+col*170,162+row*110,v,46,c,bold=True)+'</g>'
  a+=text(450,485,'Còn 3 thành phần độc lập: σx, σy, τxy',32,blue,bold=True)+note('Ứng suất chính cần xét theo hướng trục chính')
 elif kind=='free':
  a+=card(135,25,630,95,'HAI MẶT KHÔNG CÓ TẢI MẶT')
  a+=rect(145,230,600,120,'#E1EFF6',blue,0)+line(145,230,745,230,green,8)+line(145,350,745,350,green,8)
  a+=text(450,200,'z = +t/2: σz = τxz = τyz = 0',30,green,bold=True)+text(450,400,'z = −t/2: σz = τxz = τyz = 0',30,green,bold=True)
  a+=text(450,300,'BÊN TRONG: CẦN KIỂM TRA',28,blue,bold=True)+ar(800,340,800,220,red)+text(830,220,'z',32,red,bold=True)
  a+=note('Mặt cắt chiều dày được phóng đại')
 elif kind=='criteria':
  a+=card(90,35,720,120,'1. CHIỀU DÀY ĐỦ NHỎ','t / Lđặc trưng nhỏ')
  a+=card(90,205,720,120,'2. TẢI CHỦ YẾU TRONG MẶT PHẲNG','Xét cả lệch tâm và uốn ngoài mặt phẳng')
  a+=card(90,375,720,120,'3. LIÊN KẾT CHO PHÉP CO DÀY','Chú ý kẹp, tiếp xúc và vùng tải cục bộ',red)+note('Tỷ lệ hình học không tự bảo đảm mô hình đúng')
 elif kind=='poisson':
  a+=text(450,45,'VÍ DỤ GIẢ ĐỊNH · ĐÀN HỒI ĐẲNG HƯỚNG',29,blue,bold=True)+text(450,100,'E = 200 GPa · ν = 0,3',35,blue,bold=True)
  a+=rect(170,165,560,135,'none','#78888D',0,'stroke-dasharray="12 10"')
  a+='<g class="contract">'+rect(140,190,620,85,'#E1EFF6',blue,0)+'</g>'+ar(135,233,55,233)+ar(765,233,845,233)
  a+=text(450,345,'σx = 100 MPa · σy = 0 · σz = 0',33,blue,bold=True)+text(450,415,'εz = −0,3 × 100 / 200.000',35,ink,bold=True)+text(450,485,'εz = −0,00015 = −150 µε',42,red,bold=True)+note('Co chiều dày được phóng đại để dễ nhìn')
 elif kind=='strain':
  a+=card(40,35,390,110,'ỨNG SUẤT PHẲNG','σz = 0',blue)+card(470,35,390,110,'BIẾN DẠNG PHẲNG','εz = γxz = γyz = 0',red)
  a+='<g class="freebar">'+rect(95,220,280,80,'#E1EFF6',blue,0)+'</g>'+text(235,360,'εz có thể ≠ 0',31,blue,bold=True)
  a+=rect(515,220,300,80,'#FFE1BD',red,0)+line(500,205,830,205,ink,12)+line(500,315,830,315,ink,12)
  a+=text(665,360,'σz có thể ≠ 0',31,red,bold=True)+text(450,440,'Nếu εz = 0: σz = ν(σx + σy)',35,red,bold=True)+text(450,490,'Cùng σx = 100, σy = 0 → σz = 30 MPa',30,ink,bold=True)+note('Ví dụ cùng ứng suất đã cho · Không phải cùng lời giải')
 elif kind=='hole':
  a+=text(450,45,'KÉO TRONG MẶT PHẲNG · HAI MẶT RỘNG TỰ DO',28,blue,bold=True)+plate(True)+ar(190,240,60,240)+ar(735,240,855,240)
  a+=f'<circle class="hotspot" cx="450" cy="167" r="17" fill="{red}"/><circle class="hotspot" cx="450" cy="313" r="17" fill="{red}"/>'
  a+=line(465,162,635,90,red,4)+text(655,80,'Vùng quanh lỗ',28,red,bold=True)+text(450,455,'2D có thể mô tả tập trung ứng suất',34,blue,bold=True)+note('Các chấm chỉ đánh dấu vùng · Không phải bản đồ FEA')
 elif kind=='bending':
  a+=text(450,45,'TẢI NGOÀI MẶT PHẲNG',33,red,bold=True)
  a+=path('M120 220 Q450 430 780 220 L780 240 Q450 450 120 240 Z',blue,5,'#E1EFF6',extra='class="bend"')
  a+=ar(450,100,450,320,red)+text(500,125,'Fz',35,red,bold=True)
  a+=support(120,240)+support(780,240)
  a+=text(450,440,'CẦN GIỮ CƠ CHẾ UỐN',35,red,bold=True)+note('Xét tấm / vỏ / 3D · Võng chỉ minh họa')
 elif kind=='vessel':
  a+=text(450,42,'BÌNH TRỤ KÍN HAI ĐẦU · XA CHỖ NỐI',29,blue,bold=True)
  a+=path('M180 150 C180 95 720 95 720 150 V290 C720 345 180 345 180 290 Z',blue,5,'#E1EFF6')+f'<ellipse cx="450" cy="150" rx="270" ry="45" fill="#D6E6ED" stroke="{blue}" stroke-width="5"/>'
  a+=ar(450,210,310,210,red)+ar(450,210,590,210,red)+text(450,275,'P = 1 MPa',32,red,bold=True)
  a+=text(450,370,'r = 100 mm · t = 2 mm · t/r = 0,02',31,blue,bold=True)
  a+=text(450,425,'σθ ≈ Pr/t = 50 MPa',38,blue,bold=True)+text(450,478,'σa ≈ Pr/(2t) = 25 MPa',36,blue,bold=True)+note('σr: −1 → 0 MPa · Nhỏ tương đối, không triệt tiêu')
 elif kind=='gear':
  a+=text(450,45,'XÉT UỐN CHÂN RĂNG VÀ BỀ RỘNG b',30,blue,bold=True)
  a+=path('M150 390 H300 L335 120 H510 L545 390 H700 V440 H150 Z',blue,6,'#E1EFF6')
  a+=path('M510 120 L565 90 L600 360 L545 390 Z',blue,4,'#BFD4DD')+path('M335 120 L390 90 H565 L510 120 Z',blue,4,'#D8E6EA')
  a+=ar(650,165,530,210,red)+text(670,150,'F',35,red,bold=True)+line(525,120,580,90,red,5)+text(615,115,'b',35,red,bold=True)
  a+=text(450,490,'Hẹp + tải phù hợp: có thể xét 2D',32,blue,bold=True)+note('Lệch tải / tiếp xúc phức tạp: đánh giá hiệu ứng 3D')
 elif kind=='closing':
  a+=card(180,20,540,95,'HÌNH HỌC · TẢI · LIÊN KẾT')+branch(450,115,450,155)+branch(170,155,730,155)
  for x,t,sub,c in [(35,'TRONG MẶT','Ứng suất phẳng',blue),(325,'UỐN TẤM','Tấm / vỏ',red),(615,'CỤC BỘ 3D','3D / cục bộ',red)]:
   a+=branch(x+125,155,x+125,205,c)+card(x,205,250,135,t,sub,c)
  a+=branch(160,340,160,380)+branch(740,340,740,380,red)+branch(160,380,740,380)+branch(450,340,450,410)
  a+=card(170,410,560,95,'KIỂM CHỨNG & SAI SỐ')+note('Hội tụ lưới ≠ tự chứng minh mô hình vật lý đúng')
 return a+'</svg>'
