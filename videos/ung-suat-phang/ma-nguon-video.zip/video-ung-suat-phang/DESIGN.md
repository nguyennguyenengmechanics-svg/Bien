# Visual identity — Ứng suất phẳng: mô hình đúng, điều kiện rõ
## Style Prompt
Continue the user's cream engineering infographic video series. Large technical SVG drawings of thin plates, thickness contraction, restrained elements and a thin pressure vessel. Bold orange keywords, saturated blue in-plane arrows, orange out-of-plane constraints and warnings, dark green criteria. Use thick colored branches and pale panels. The viewer should see the physical distinction between plane stress and plane strain. Every deformation is schematic and exaggerated; no FEA has been performed.
## Colors
- #F1F0E4 cream background
- #142D38 ink, structure
- #B83B16 orange emphasis and constraints
- #0A527B saturated blue, in-plane loading and data
- #2D6842 green, validity checks
- #FFE1BD pale orange highlight
- #FFFFFF white diagram cards
## Typography
DejaVu Serif Bold display 78px; DejaVu Sans regular captions36px, bold key phrases. SVG labels at least28px in900unit viewBox. Wrap inline highlights inside spans to keep natural text flow in flex parents.
## Motion
Paused seekable deterministic GSAP. Push transitions between scenes. Staged tensor entries, thickness contraction, restraint reveal, membrane loads and cross-section arrows. Finite motion; hold completed diagrams while explaining them. First frame already has a title.
## What NOT to Do
- Do not confuse plane stress with plane strain.
- Do not label σx, σy, τxy as principal stresses.
- Do not claim thickness ratio0.1 guarantees validity.
- Do not infer zero transverse stress in the interior solely from free faces.
- Do not call diagrams simulations or measured data.
- Avoid tiny paragraphs, stock robots and decorative motion.
