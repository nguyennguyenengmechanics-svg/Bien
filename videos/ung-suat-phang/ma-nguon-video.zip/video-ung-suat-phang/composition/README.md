# Video ứng suất phẳng trong thiết kế cơ khí

1080×1920, 30fps, giọng Việt tổng hợp, phụ đề và sơ đồ SVG chuyển động. Các tài nguyên phát lại đều nằm trong assets.

Dùng HyperFrames CLI0.9.0 tại thư mục composition:

```sh
npx hyperframes preview
npx hyperframes check --samples 15
npx hyperframes render . --output ung-suat-phang.mp4 --fps 30 --quality high
```

Nếu có Chromium hệ thống, đặt HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium. Gói nguồn giữ thư mục composition và output bên cạnh build.py, diagrams.py, scenes.json, timing.json và music.py. Chạy python build.py từ thư mục gốc để dựng lại HTML. Không cần mô hình TTS để render lại từ HTML và WAV có sẵn.

Xem output/GHI-CHU.txt về giả thiết kỹ thuật, hiệu chỉnh so với PDF và giấy phép.
