from pathlib import Path
import json,html,re
from graphics import svg
R=Path(__file__).parent;P=R/'composition';O=R/'output';O.mkdir(exist_ok=True)
S=json.loads((R/'timing.json').read_text());cfg=json.loads((R/'project.json').read_text());T=S[-1]['start']+S[-1]['duration']
def rich(t,words):
 s=html.escape(t);selected=[w for w in sorted(words,key=len,reverse=True) if w.casefold() in t.casefold()][:2]
 if not selected:return s
 return re.sub('|'.join(re.escape(html.escape(w)) for w in selected),lambda m:'<strong>'+m.group()+'</strong>',s,flags=re.I)
CSS='''@font-face{font-family:Serif;src:url(assets/DejaVuSerif-Bold.ttf);font-weight:700}@font-face{font-family:Sans;src:url(assets/DejaVuSans.ttf);font-weight:400}@font-face{font-family:Sans;src:url(assets/DejaVuSans-Bold.ttf);font-weight:700}@font-face{font-family:Mono;src:url(assets/DejaVuSansMono.ttf)}*{box-sizing:border-box}html,body{margin:0;width:1080px;height:1920px;overflow:hidden;font-family:Sans;color:#142D38;background:#F1F0E4}#root{position:relative;width:1080px;height:1920px}.scene{position:absolute;inset:0;background:#F1F0E4;overflow:hidden}.scene-content{width:100%;height:100%;padding:72px 80px 70px;display:flex;flex-direction:column;gap:20px}.header{display:flex;justify-content:space-between;border-bottom:2px solid #142D3830;padding-bottom:18px;font-size:28px;letter-spacing:2px;font-weight:700}.header b{color:#B83B16}.kicker{font-size:28px;letter-spacing:2px;color:#B83B16;font-weight:700;margin-top:8px}.headline{font-family:Serif;font-size:82px;line-height:1.12;letter-spacing:-3px;margin:0;white-space:pre-line;height:200px;display:flex;align-items:center;flex-shrink:0}.headline strong{color:#B83B16}.lede{font-size:29px;font-weight:700;color:#0A527B;min-height:54px;line-height:1.4}.stage{width:920px;height:920px;flex-shrink:0;position:relative;border-radius:30px;background-image:radial-gradient(#142D380d 1.4px,transparent 1.4px);background-size:26px 26px}.stage svg{width:100%;height:100%;overflow:visible;display:block}.caption-zone{height:218px;position:relative;flex-shrink:0}.caption{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;font-size:39px;line-height:1.45;padding:10px 5px;opacity:0}.caption strong{font-weight:700;color:#A82F0D;background:#FFE1BD;padding:1px 5px;border-radius:5px}.footer{margin-top:auto;display:flex;justify-content:space-between;font-size:28px;color:#2D6842;line-height:1.4}.progress{position:absolute;bottom:45px;left:80px;width:920px;height:5px;background:#142D3817;z-index:50}.fill{height:100%;background:#B83B16;transform-origin:left}.g1,.g2,.g3,.gear{transform-origin:0px 0px}svg text{font-variant-numeric:tabular-nums}.new{transform-box:fill-box;transform-origin:center}'''
parts=['<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><title>'+cfg['title']+'</title><script src="assets/gsap.min.js"></script><style>'+CSS+'</style></head><body>',f'<div id="root" data-composition-id="main" data-width="1080" data-height="1920" data-start="0" data-duration="{T:.3f}">']
A=[];subtitles=[];count=0
for i,s in enumerate(S):
 ident=f's{i}';a=s['start'];end=a+s['duration'];q=[x['start'] for x in s['segments']];d=[x['duration'] for x in s['segments']]
 caps=''
 for j,seg in enumerate(s['segments']):
  el=f'cap{i}-{j}';t=seg['start'];e=t+seg['duration']
  caps+=f'<div id="{el}" class="caption"><span>{rich(seg["text"],s["highlights"])}</span></div>'
  A.append(f'tl.to("#{el}",{{opacity:1,duration:.16,ease:"sine.out"}},{t});tl.to("#{el}",{{opacity:0,duration:.12,ease:"power2.in"}},{e+.1});tl.set("#{el}",{{opacity:0}},{e+.23});')
  count+=1
  def stamp(t):
   ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
  subtitles.append(f'{count}\n{stamp(t)} --> {stamp(e)}\n{seg["text"]}\n')
 parts.append(f'<section class="scene" id="{ident}" style="opacity:{1 if i==0 else 0};z-index:{i+1}" data-layout-allow-overflow><div class="scene-content"><div class="header"><span>API · CLI · MCP</span><b>GIẢI THÍCH TRỰC QUAN / {i+1:02}</b></div><div class="kicker">{s["tag"]}</div><h1 class="headline"><span>{rich(s["title"],s["title_em"])}</span></h1><div class="lede">{html.escape(s["key"])}</div><div class="stage">{svg(s["diagram"])}</div><div class="caption-zone">{caps}</div><div class="footer"><span>Ví dụ giả định · Sơ đồ minh họa</span><span>{i+1:02} / 09</span></div></div></section>')
 def show(sel,t,dur=.55,**kw):
  props=dict(opacity=0,duration=dur,ease=kw.pop('ease','power3.out'));props.update(kw);A.append(f'tl.from("#{ident} {sel}",{json.dumps(props)},{round(t,3)});')
 def move(sel,t,dur=.7,**kw):
  props=dict(duration=dur,ease=kw.pop('ease','power2.inOut'));props.update(kw)
  if 'rotation' in props:props['transformOrigin']='50% 50%'
  A.append(f'tl.to("#{ident} {sel}",{json.dumps(props)},{round(t,3)});')
 if i:
  axis='y' if i in [4,7] else 'x';distance=1920 if axis=='y' else 1080
  A.append(f'tl.to("#s{i-1}",{{{axis}:-{distance},duration:.48,ease:"power3.inOut"}},{a});tl.set("#s{i-1}",{{opacity:0}},{a+.48});')
  A.append(f'tl.fromTo("#{ident}",{{{axis}:{distance},opacity:1}},{{{axis}:0,opacity:1,duration:.48,ease:"power3.inOut",immediateRender:false}},{a});')
  show('.headline',a+.2,.62,y=28,ease='power4.out')
 show('.header',a+.12,.35,y=-12,ease='power2.out');show('.kicker',a+.23,.4,x=-20,ease='expo.out');show('.lede',a+.35,.5,x=25,ease='sine.out');show('.stage',a+.42,.6,scale=.97,ease='power2.out');show('.footer',a+.5,.45,ease='sine.out')
 k=s['diagram']
 if k=='sale':
  show('.setup',a+.6,.7,scale=.8,ease='back.out(1.1)')
  for j in range(3):show(f'.p{j}',a+1.1+j*.18,.6,y=60,ease='power3.out');show(f'.n{j}',q[1]+.8+j*.8,.55,scale=.3,ease='back.out(1.3)')
  show('.routes',q[2],.6,y=30,ease='expo.out');move('.setup',q[1],.6,scale=1.04);move('.setup',q[1]+.6,.6,scale=1)
 elif k=='restaurant':
  show('.order',a+.7,.5,x=-60,ease='back.out(1.05)');show('.counter',a+1.4,.7,x=-70);show('.kitchen',a+1.8,.8,x=80,ease='expo.out');show('.road',a+2.3,.6,scaleX=0)
  show('.ticket',q[0]+2.5,.25,scale=.3);move('.ticket',q[0]+2.8,1.6,x=160,y=0,ease='power1.inOut')
  move('.g1',q[1],d[1],rotation=260,ease='none');move('.g2',q[1],d[1],rotation=-260,ease='none')
  show('.burger',q[1]+1.2,.65,scale=.5,y=60,ease='back.out(1.2)')
  for sel,delta in [('.bun-top',-60),('.lettuce',-20),('.patty',30),('.bun-bottom',70)]:show('.burger '+sel,q[1]+1.7,.8,y=delta,ease='power2.out')
  show('.result',q[2],.55,y=22,ease='sine.out');move('.burger',q[3],1.2,y=-15,ease='sine.inOut')
 elif k=='api':
  show('.client',a+.7,.6,x=-60);show('.shop',a+.95,.7,x=70,ease='expo.out');show('.link',a+1.5,.6,scaleX=0)
  show('.request',q[1],.65,y=45,ease='power4.out');show('.send',q[1]+1.2,.3,scale=.4);move('.send',q[1]+1.5,1.8,x=330,ease='power1.inOut')
  show('.reply',q[2]+.3,.65,y=65,ease='back.out(1.08)');show('.ok',q[3],.5,scale=.8,ease='back.out(1.1)')
 elif k=='repeat':
  show('.inputs',a+.6,.6,y=-50);show('.engine',a+.9,.7,scale=.8,ease='back.out(1.1)');show('.rails',a+1.4,.6,ease='sine.out')
  show('.batchA',q[0]+2.4,.3,scale=.5);move('.batchA',q[0]+2.8,1.2,y=140)
  show('.batchB',q[1]+1,.3,x=230);move('.batchB',q[1]+1.4,1.3,y=140)
  move('.g1',q[0]+3, min(end-q[0]-4,16),rotation=660,ease='none')
  show('.output',q[1]+2.8,.5,y=25);show('.cost',q[2],.6,y=30,ease='expo.out')
 elif k=='mcp':
  show('.ask',a+.6,.55,x=-65,ease='back.out(1.05)');show('.agent',a+1.1,.7,scale=.7,ease='back.out(1.2)');show('.server',a+1.5,.75,x=90,ease='expo.out');show('.link',a+2,.6,scaleX=0)
  show('.selection',q[1],.45,scale=.94,ease='power2.out');move('.selection',q[1]+2,1,y=100,ease='power3.inOut')
  show('.call',q[1]+2.8,.25,scale=.4);move('.call',q[1]+3.1,1.2,x=130)
  show('.backend',q[2],.7,y=50,ease='expo.out');move('.call',q[2]+.2,.9,x=220,y=255);show('.report',q[2]+2.5,.55,scale=.85,ease='back.out(1.2)')
  move('.agent',q[3],.8,scale=1.025,ease='sine.inOut');move('.agent',q[3]+.8,.8,scale=1,ease='sine.inOut')
 elif k=='cli':
  show('.terminal',a+.6,.6,y=45,ease='power4.out');show('.cmd1',a+1.2,.35,x=-20);show('.cmd2',q[1],.6,x=-35,ease='expo.out');show('.note',a+1.2,.5,ease='sine.out')
  show('.rails',q[1]+.6,.55,scaleX=0)
  for j in range(3):show(f'.step{j}',q[1]+.8+j*.65,.6,scale=.6,ease='back.out(1.2)');move(f'.g{j+1}',q[1]+1.1+j*.65,4.5,rotation=(1 if j%2==0 else -1)*240,ease='none')
  show('.fileout',q[2],.75,y=70,ease='power3.out')
 elif k=='layers':
  show('.route1',a+.8,.7,x=-70);show('.q1',q[0]+2,.25,scale=.5);move('.q1',q[0]+2.3,1.2,x=310)
  show('.route2',q[1],.7,x=70,ease='expo.out');show('.shop2',q[1]+1,.7,y=70);show('.q2',q[1]+1.8,.3,scale=.5);move('.q2',q[1]+2.2,1.3,x=340,y=105)
  show('.local',q[3],.6,y=25,ease='sine.out')
 elif k=='choose':
  show('.question',a+.65,.6,scale=.6,ease='back.out(1.1)');show('.branch',a+1.1,.6,scaleY=0,ease='power2.out')
  for j in range(3):show(f'.choice{j}',q[j]+1,.65,y=65,ease=['power4.out','expo.out','back.out(1.1)'][j])
  show('.examples',q[2]+1.8,.7,y=18,ease='sine.out');show('.pick',a+1.6,.4,scale=.2)
  move('.pick',q[0]+2,1,x=-310,y=70);move('.pick',q[1]+2,1,x=0,y=70);move('.pick',q[2]+2,1,x=310,y=70)
  show('.meter',q[3],.6,scale=.9,ease='back.out(1.06)')
 elif k=='end':
  for j in range(3):show(f'.role{j}',a+.7+j*.25,.65,scale=.6,ease='back.out(1.1)')
  show('.thread',q[1],.6,scaleY=0,ease='power2.out');show('.lock',q[2],.65,y=45,ease='expo.out');show('.final',q[3],.7,y=28,ease='sine.out')
parts.append(f'<div class="progress"><div class="fill" id="progress"></div></div><audio id="voiceover" src="assets/narration.flac" data-start="0" data-duration="{T:.3f}" data-track-index="2" data-volume="1"></audio><audio id="music" src="assets/music.flac" data-start="0" data-duration="{T:.3f}" data-track-index="3" data-volume="1"></audio></div>')
A.append(f'tl.from("#progress",{{scaleX:0,duration:{T},ease:"none"}},0);')
parts.append('<script>window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});'+''.join(A)+'window.__timelines.main=tl;</script></body></html>')
(P/'index.html').write_text(''.join(parts));(O/'phu-de.vi.srt').write_text('\n'.join(subtitles));(O/'loi-dan.txt').write_text('\n\n'.join(s['tag']+'\n'+' '.join(s['voice']) for s in S))
print('Built',round(T,3),'seconds',count,'captions')
