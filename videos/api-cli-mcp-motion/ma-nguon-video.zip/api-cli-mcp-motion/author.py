import pathlib,json
R=pathlib.Path(__file__).parent
P=dict(title='API · CLI · MCP — Một ví dụ, ba cách làm',brand='GIẢI THÍCH BẰNG CHUYỂN ĐỘNG',footer='Ví dụ giả định · Sơ đồ minh họa',slug='api-cli-mcp-motion',fps=30,demo=False)
S=[
dict(tag='01 / CÙNG MỘT MỤC TIÊU',title='Cùng giảm 20%.\nBa cách làm.',title_em=['20%','Ba cách'],key='Một cửa hàng mẫu · ba sản phẩm · một quy tắc',diagram='sale',highlights=['20%','API','CLI','MCP'],voice=[
'Giả sử bạn có một cửa hàng và muốn giảm hai mươi phần trăm cho ba sản phẩm trong nhóm áo.',
'Chiếc áo giá một trăm nghìn còn tám mươi nghìn. Áo hai trăm còn một trăm sáu mươi. Quy tắc rất rõ ràng.',
'Bạn có thể viết chương trình gọi ây pi ai, chạy một câu lệnh xi eo ai, hoặc giao mục tiêu cho AI qua em xi pi.',
'Cùng một kết quả, nhưng cách tổ chức công việc khác nhau. Hãy theo dõi từng đường đi của yêu cầu.'],captions=[
'Bài toán: giảm 20% cho ba sản phẩm trong nhóm Áo.',
'100 → 80; 200 → 160; 300 → 240 nghìn đồng.',
'API, CLI hoặc AI kết nối qua MCP: nhiều cách thực hiện.',
'Cùng kết quả; khác cách tổ chức công việc.']),
dict(tag='02 / HIỂU GIAO DIỆN',title='Đặt đúng yêu cầu.\nNhận đúng kết quả.',title_em=['yêu cầu','kết quả'],key='Bạn không cần biết mọi chi tiết bên trong',diagram='restaurant',highlights=['giao diện','yêu cầu','API'],voice=[
'Trước hết, hãy tưởng tượng bạn đặt một chiếc bánh ở quầy. Bạn chọn món, gửi đơn và nhận chiếc bánh.',
'Bạn không cần biết bếp chia ca thế nào hay nguyên liệu được cất ở đâu. Quầy đặt món che đi những chi tiết ấy.',
'Ây pi ai cũng là một giao diện, nhưng dành cho phần mềm. Chương trình gửi yêu cầu theo quy tắc mà giao diện công bố.',
'Nhớ điểm khác biệt: trong ví dụ nhà hàng, bạn đặt món; còn với ây pi ai, chương trình gửi dữ liệu có cấu trúc.'],captions=[
'Chọn món → gửi đơn → nhận bánh.',
'Giao diện che đi cách tổ chức bên trong.',
'API là giao diện để phần mềm yêu cầu chức năng.',
'API: gửi dữ liệu đúng cấu trúc và quy tắc.']),
dict(tag='03 / ĐƯỜNG ĐI API',title='API: yêu cầu\ncó cấu trúc.',title_em=['API','cấu trúc'],key='Giao diện lập trình ứng dụng',diagram='api',highlights=['tham số','yêu cầu','API','kết quả'],voice=[
'Quay lại cửa hàng. Chương trình đọc tài liệu để biết thao tác giảm giá cần những tham số và quyền truy cập nào.',
'Nó tạo yêu cầu gồm nhóm sản phẩm và mức giảm hai mươi phần trăm, rồi gửi tới địa chỉ dịch vụ quy định.',
'Dịch vụ kiểm tra, cập nhật giá và trả kết quả. Chẳng hạn, một đối tượng dữ liệu ghi rằng ba sản phẩm đã được xử lý.',
'Bạn không tự bịa tên trường hay bỏ qua lỗi trả về. Cần đúng tài liệu, đúng phiên bản và kiểm tra kết quả.'],captions=[
'Đọc tài liệu: thao tác, tham số và quyền truy cập.',
'Tạo yêu cầu: nhóm Áo + mức giảm 20% → gửi API.',
'Dịch vụ xử lý → trả kết quả có cấu trúc.',
'Đúng tài liệu, đúng phiên bản; luôn kiểm tra kết quả.']),
dict(tag='04 / QUY TRÌNH LẶP LẠI',title='Viết một lần.\nChạy lại.',title_em=['một lần','Chạy lại'],key='Thay dữ liệu đầu vào, giữ quy trình đã kiểm tra',diagram='repeat',highlights=['kịch bản','AI','chi phí','đầu vào'],voice=[
'Khi đã viết một kịch bản ổn định, bạn có thể chạy lại với nhóm sản phẩm khác mà không nhờ AI suy nghĩ từ đầu.',
'Hãy nhìn: đổi đầu vào từ nhóm áo sang nhóm túi, còn các bước kiểm tra, gửi yêu cầu và đọc kết quả vẫn được giữ lại.',
'Trong kịch bản không gọi mô hình AI này, mỗi lần chạy không cần token suy luận của mô hình. Nhưng không có nghĩa mọi chi phí bằng không.',
'Dịch vụ vẫn có thể tính phí, giới hạn tốc độ hoặc thay đổi giao diện. Mã vẫn cần theo dõi và bảo trì.'],captions=[
'Tái sử dụng kịch bản đã kiểm tra, không cần AI lập lại kế hoạch.',
'Đổi đầu vào; giữ các bước kiểm tra và xử lý.',
'Không gọi mô hình AI ≠ mọi chi phí đều bằng 0.',
'Vẫn có phí dịch vụ, giới hạn tốc độ và công bảo trì.']),
dict(tag='05 / ĐƯỜNG ĐI MCP',title='Bạn nói ý định.\nAI chọn công cụ.',title_em=['ý định','công cụ'],key='MCP = Model Context Protocol · chuẩn kết nối',diagram='mcp',highlights=['MCP','tham số','AI','công cụ'],voice=[
'Với em xi pi, bạn nói: hãy giảm hai mươi phần trăm cho nhóm áo. Ứng dụng AI tìm công cụ phù hợp mà máy chủ cung cấp.',
'AI chuyển ý định thành tham số có cấu trúc. Nó có thể gọi công cụ liệt kê sản phẩm, rồi công cụ cập nhật giá.',
'Máy chủ thực thi, chẳng hạn bằng cách gọi ây pi ai của cửa hàng, rồi gửi kết quả về cho AI đọc và báo lại.',
'Vậy ngôn ngữ tự nhiên nằm ở cuộc trò chuyện với AI. Em xi pi chuẩn hóa kết nối công cụ; không tự bảo đảm mọi thao tác luôn đúng.'],captions=[
'Bạn: “Giảm 20% nhóm Áo.” → AI tìm công cụ qua MCP.',
'AI chọn công cụ và điền tham số có cấu trúc.',
'MCP server thực thi → trả kết quả → AI báo lại.',
'Ngôn ngữ tự nhiên ở lớp AI; MCP chuẩn hóa kết nối.']),
dict(tag='06 / ĐƯỜNG ĐI CLI',title='Một câu lệnh.\nNhiều bước.',title_em=['Một câu lệnh','Nhiều bước'],key='CLI = Command Line Interface · dòng lệnh',diagram='cli',highlights=['CLI','câu lệnh','quy trình','API'],voice=[
'Còn xi eo ai là giao diện dòng lệnh. Một công cụ có thể đóng gói quy trình thành câu lệnh ngắn để người hoặc AI chạy.',
'Trong ví dụ minh họa này, bạn chỉ nhập nhóm áo và mức giảm. Công cụ lần lượt đọc cấu hình, lấy sản phẩm rồi cập nhật giá.',
'Phía sau câu lệnh vẫn có thể là ây pi ai. Công cụ cũng có thể lưu tệp báo cáo ngay trên máy.',
'Điều kiện là có môi trường chạy lệnh và quyền phù hợp. Câu lệnh không bảo đảm thành công: vẫn phải kiểm tra mã thoát và kết quả.'],captions=[
'CLI đóng gói thao tác thành câu lệnh cho người hoặc AI chạy.',
'Nhập nhóm Áo + mức giảm → công cụ chạy các bước đã định.',
'Phía sau CLI có thể là API; kết quả có thể lưu thành tệp.',
'Cần môi trường chạy, đúng quyền và kiểm tra kết quả.']),
dict(tag='07 / GHÉP CÁC VAI TRÒ',title='Có thể kết hợp.\nKhông loại trừ nhau.',title_em=['kết hợp'],key='Đừng nhầm giao diện sử dụng với giao thức kết nối',diagram='layers',highlights=['CLI','API','MCP','AI'],voice=[
'Bây giờ ghép hai đường đi lại. Ở đường thứ nhất, bạn chạy xi eo ai; công cụ gọi ây pi ai để đổi giá trong cửa hàng.',
'Ở đường thứ hai, ứng dụng AI gọi công cụ qua em xi pi; máy chủ có thể gọi cùng ây pi ai đó.',
'Đây không phải cuộc thi để loại bỏ hai công cụ còn lại. Mỗi khái niệm giải quyết một phần khác nhau của hệ thống.',
'Và không phải máy chủ em xi pi hay xi eo ai nào cũng cần dịch vụ trên mạng. Chúng còn có thể làm việc với tệp cục bộ.'],captions=[
'Bạn → CLI → API → cửa hàng.',
'Ứng dụng AI → MCP server → API → cửa hàng.',
'Ba vai trò khác nhau, có thể nằm trong cùng hệ thống.',
'CLI và MCP server còn có thể xử lý dữ liệu cục bộ.']),
dict(tag='08 / CHỌN CHO ĐÚNG VIỆC',title='Việc đã rõ,\nhay cần khám phá?',title_em=['rõ','khám phá'],key='Chọn theo tác vụ, môi trường và mức kiểm soát',diagram='choose',highlights=['API','CLI','MCP','đo'],voice=[
'Nếu cần đồng bộ tồn kho theo quy tắc cố định, hãy cân nhắc kịch bản gọi ây pi ai: luồng rõ, dễ chạy lại và kiểm soát.',
'Nếu đã có công cụ gom nhiều bước thành câu lệnh tốt, xi eo ai là cách thuận tiện để vận hành quy trình đó.',
'Nếu chưa rõ nguyên nhân doanh số giảm và muốn hỏi tiếp để khám phá dữ liệu, AI kết nối qua em xi pi có thể phù hợp.',
'Chi phí token phụ thuộc cả cách ứng dụng tìm công cụ, số lần gọi và dữ liệu trả về. Hãy đo cùng tác vụ, đừng mặc định cách nào luôn rẻ hơn.'],captions=[
'Quy trình cố định, cần kiểm soát → cân nhắc kịch bản gọi API.',
'Đã có câu lệnh tốt cho nhiều bước → cân nhắc CLI.',
'Hỏi đáp, khám phá dữ liệu → cân nhắc AI kết nối qua MCP.',
'Đo cùng tác vụ; không có cách luôn rẻ hơn trong mọi tình huống.']),
dict(tag='09 / GHI NHỚ',title='Nhớ đúng vai trò.\nChọn đúng công cụ.',title_em=['vai trò','công cụ'],key='API: giao diện · CLI: câu lệnh · MCP: chuẩn kết nối',diagram='end',highlights=['API','CLI','MCP','quyền'],voice=[
'Hãy nhớ ba hình ảnh: ây pi ai là cửa nhận yêu cầu có cấu trúc; xi eo ai là bảng lệnh; em xi pi là kết nối chuẩn cho ứng dụng AI.',
'Cùng việc giảm giá, bạn có thể dùng một cách hoặc phối hợp nhiều cách. Điều quan trọng là hiểu đường đi của dữ liệu.',
'Bắt đầu từ một tác vụ nhỏ. Kiểm tra đúng tài khoản, cấp quyền vừa đủ và xem kết quả trước khi chạy hàng loạt.',
'Khi việc đã rõ, hãy chuẩn hóa quy trình. Khi cần khám phá, hãy dùng AI đúng chỗ. Chọn theo việc, rồi đo và cải thiện.'],captions=[
'API: giao diện · CLI: câu lệnh · MCP: chuẩn kết nối AI.',
'Có thể phối hợp; hãy hiểu đường đi của dữ liệu.',
'Thử nhỏ → đúng tài khoản, đúng quyền → kiểm tra kết quả.',
'Việc rõ: chuẩn hóa. Cần khám phá: dùng AI đúng chỗ.'])]
(R/'project.json').write_text(json.dumps(P,ensure_ascii=False,indent=2));(R/'scenes.json').write_text(json.dumps(S,ensure_ascii=False,indent=2))
print('Syllables',sum(len(v.split()) for s in S for v in s['voice']))
