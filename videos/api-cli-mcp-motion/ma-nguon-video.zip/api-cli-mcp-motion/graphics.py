from html import escape as E
B='#0A527B';O='#B83B16';G='#2D6842';I='#142D38';C='#F1F0E4';P='#FFE1BD';W='#FFFFFF'
def text(x,y,t,size=38,color=I,bold=False,cls='',anchor='middle',mono=False):
 return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="{("Mono" if mono else "Sans")}" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}" class="{cls}">{E(t)}</text>'
def rect(x,y,w,h,fill=W,stroke=I,r=20,cls=''):
 return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="4" class="{cls}"/>'
def path(d,color=B,w=8,cls='',fill='none'):
 return f'<path d="{d}" fill="{fill}" stroke="{color}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round" class="{cls}"/>'
def line(x1,y1,x2,y2,c=B,w=8,cls=''):
 return path(f'M{x1} {y1}L{x2} {y2}',c,w,cls)
def circ(x,y,r,color=W,stroke=B,w=5,cls=''):
 return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}" stroke="{stroke}" stroke-width="{w}" class="{cls}"/>'
def group(cls,s):return f'<g class="{cls}">{s}</g>'
def label(x,y,w,t,color=B):return rect(x,y,w,76,W,color,16)+text(x+w/2,y+50,t,36,color,True)
def check(x,y):return circ(x,y,27,G,G)+path(f'M{x-13} {y}l9 10 19-23',W,6)
def packet(x,y,cls='packet',t='20%'):
 return group(cls,rect(x,y,112,68,P,O,12)+text(x+56,y+45,t,34,O,True))
def chip(x,y,t,c=B,w=230):return group('item',rect(x,y,w,94,W,c,18)+text(x+w/2,y+61,t,36,c,True))
def store(x,y,scale=1,cls='store'):
 s=rect(0,80,270,210,W,B,8)+path('M-15 80L20 0H250L285 80Z',B,6,P)
 for k in range(5):s+=path(f'M{k*54} 80v30q27 35 54 0V80',B,5)
 s+=rect(30,162,86,125,C,B,2)+rect(150,164,83,65,P,O,4)
 return f'<g class="{cls}" transform="translate({x} {y}) scale({scale})">{s}</g>'
def tee(x,y,scale=1,color=B,cls='shirt'):
 s=path('M0 20L65-15Q95 25 125-15L190 20L160 90L130 72V210H60V72L30 90Z',color,6,fill=W)
 return f'<g class="{cls}" transform="translate({x} {y}) scale({scale})">{s}</g>'
def fileicon(x,y,cls='file',c=B):
 return group(cls,path(f'M{x} {y}h115l45 45v165H{x}Z',c,6,fill=W)+path(f'M{x+115} {y}v45h45',c,5)+line(x+25,y+90,x+130,y+90,c,5)+line(x+25,y+125,x+130,y+125,c,5)+line(x+25,y+160,x+100,y+160,c,5))
def gear(x,y,cls='gear',color=B,r=57):
 z=circ(0,0,r,P,color,7)+circ(0,0,r*.34,W,color,6)
 for a in range(0,360,45):z+=f'<rect x="-12" y="{-r-13}" width="24" height="26" rx="5" fill="{color}" transform="rotate({a})"/>'
 return f'<g transform="translate({x} {y})"><g class="{cls}">{z}</g></g>'
def burger(x,y,cls='burger',scale=1):
 b=group('bun-top',path('M0 75Q0-30 110-30Q220-30 220 75Z',O,6,fill=P)+circ(70,20,4,I,I,1)+circ(130,9,4,I,I,1)+circ(165,40,4,I,I,1))
 b+=group('lettuce',path('M0 100q25-25 50 0t50 0t50 0t70 0',G,18))
 b+=group('patty',rect(0,125,220,35,I,I,16))+group('bun-bottom',rect(0,180,220,50,P,O,18))
 return f'<g transform="translate({x} {y}) scale({scale})"><g class="{cls}">{b}</g></g>'
def svg(kind):
 s=''
 if kind=='sale':
  s+=group('setup',circ(460,145,140,P,O,5)+text(460,165,'−20%',76,O,True)+text(460,318,'CỬA HÀNG MẪU',38,B,True))
  for k,(x,old,new) in enumerate([(40,'100','80'),(340,'200','160'),(640,'300','240')]):
   s+=group(f'product p{k}',rect(x,380,240,350,W,B,24)+tee(x+50,414,.7)+text(x+120,650,old,48,I,True)+group(f'new n{k}',path(f'M{x+75} 632l95 20',O,5)+text(x+120,709,new,54,O,True)))
  s+=group('routes',text(460,815,'API   ·   CLI   ·   MCP',56,B,True)+text(460,876,'Giá giả định · đơn vị: nghìn đồng',32,I))
 elif kind=='restaurant':
  s+=group('order',rect(35,65,380,130,W,B,30)+text(225,145,'Một chiếc bánh!',42,B,True))
  s+=group('counter',rect(35,350,275,330,W,B,25)+rect(65,390,215,185,C,B,14)+burger(120,470,'screenburger',.48)+text(172,630,'ĐẶT MÓN',32,B,True))
  s+=group('kitchen',rect(590,350,290,330,W,O,25)+text(735,413,'BẾP',44,O,True)+gear(690,520,'g1',O,43)+gear(787,575,'g2',B,43))
  s+=group('road',line(310,480,590,480,B,10)+path('M566 460l24 20-24 20',B,7))
  s+=packet(325,445,'ticket','ĐƠN')
  s+=burger(350,620,'burger',.92)+group('result',text(460,875,'Chọn món → gửi đơn → nhận bánh',38,G,True))
 elif kind=='api':
  s+=group('client',fileicon(50,55,'script')+text(130,322,'CHƯƠNG TRÌNH',32,B,True))
  s+=group('shop',store(650,40,.75)+text(750,322,'DỊCH VỤ',34,B,True))
  s+=group('link',line(220,150,630,150,B,10)+path('M600 126l30 24-30 24',B,7)+text(450,100,'API',50,B,True))
  s+=group('request',rect(65,375,790,212,I,I,24)+text(108,432,'YÊU CẦU MINH HỌA',32,'#FFFFFF',True,anchor='start')+text(108,493,'group: "Áo"',42,'#FFFFFF',anchor='start',mono=True)+text(108,553,'discount_percent: 20',42,'#FFFFFF',anchor='start',mono=True))
  s+=packet(235,115,'send')
  s+=group('reply',rect(140,658,640,145,W,G,20)+text(460,712,'KẾT QUẢ MINH HỌA',34,G,True)+text(460,770,'{ updated: 3 }',48,G,True,mono=True))
  s+=group('ok',check(820,730)+text(460,876,'Kiểm tra lỗi và phiên bản API',36,O,True))
 elif kind=='repeat':
  s+=group('inputs',chip(40,60,'NHÓM ÁO',B,270)+chip(610,60,'NHÓM TÚI',O,270))
  s+=group('engine',rect(270,270,380,310,W,B,40)+gear(460,420,'g1',B,85)+text(460,540,'KỊCH BẢN',44,B,True))
  s+=group('rails',path('M175 154V205H460V270 M745 154V205H460',B,9)+line(460,580,460,675,G,9))
  s+=packet(405,180,'batchA','ÁO')+packet(405,180,'batchB','TÚI')
  s+=group('output',label(200,680,520,'GIỮ NGUYÊN QUY TRÌNH',G))
  s+=group('cost',text(460,830,'Không gọi AI ≠ không có chi phí',39,O,True)+text(460,888,'Phí dịch vụ · giới hạn · bảo trì',34,I))
 elif kind=='mcp':
  s+=group('ask',rect(45,40,830,120,W,O,28)+text(460,116,'“Giảm 20% cho nhóm Áo.”',46,O,True))
  s+=group('agent',circ(200,310,105,W,B,8)+circ(200,310,70,P,O,3)+text(200,329,'AI',66,B,True)+text(200,469,'ỨNG DỤNG AI',32,B,True))
  s+=group('server',rect(470,220,405,295,W,B,24)+text(672,275,'MCP SERVER',42,B,True)+rect(500,305,345,76,C,B,12)+text(672,355,'Liệt kê sản phẩm',32,B,True)+rect(500,405,345,76,P,O,12)+text(672,455,'Cập nhật giá',34,O,True))
  s+=group('link',line(310,310,462,310,B,9)+path('M438 290l24 20-24 20',B,6))
  s+=packet(325,277,'call','CALL')
  s+=group('selection',rect(485,294,375,100,'none',O,15))
  s+=group('backend',line(670,515,670,595,B,8)+store(570,605,.68)+text(662,863,'API CỬA HÀNG',34,B,True))
  s+=group('report',label(50,660,385,'ĐÃ XỬ LÝ: 3',G)+check(242,805))
 elif kind=='cli':
  s+=group('terminal',rect(30,45,860,245,I,I,30)+circ(70,82,8,O,O,1)+circ(102,82,8,P,P,1)+circ(134,82,8,G,G,1)+text(70,158,'$ shop sale',47,'#FFFFFF',True,'cmd1',anchor='start',mono=True)+text(70,226,'--group shirts --off 20',44,'#FFFFFF',False,'cmd2',anchor='start',mono=True))
  s+=group('note',text(460,345,'Lệnh giả định để minh họa quy trình',32,O))
  for k,(x,label_) in enumerate([(170,'CẤU HÌNH'),(460,'LẤY HÀNG'),(750,'ĐỔI GIÁ')]):
   s+=group(f'step step{k}',gear(x,515,f'g{k+1}',B if k!=1 else O,65)+text(x,655,f'0{k+1}',42,O,True)+text(x,712,label_,34,B,True))
  s+=group('rails',line(250,515,380,515,B,9)+line(540,515,670,515,O,9))
  s+=group('fileout',('<g transform="translate(410 770) scale(.6)">'+fileicon(0,0,'file',G)+'</g>')+text(170,854,'API',44,B,True)+text(746,854,'TỆP',44,G,True))
 elif kind=='layers':
  s+=group('route1',text(45,55,'01 · BẠN CHẠY CÂU LỆNH',35,O,True,anchor='start')+chip(45,115,'CLI',O,200)+chip(355,115,'API',B,200)+store(690,84,.62)+line(250,162,350,162,O,9)+line(560,162,680,162,B,9))
  s+=packet(265,125,'q1','LỆNH')
  s+=group('route2',text(45,410,'02 · AI CHỌN CÔNG CỤ',35,B,True,anchor='start')+chip(45,480,'AI',B,160)+chip(280,480,'MCP',O,190)+chip(550,480,'API',B,170)+line(210,528,275,528,B,9)+line(475,528,545,528,O,9))
  s+=group('shop2',store(690,650,.62)+text(340,783,'CÙNG DỊCH VỤ',40,G,True)+path('M720 528H790V640',B,8))
  s+=packet(212,495,'q2','GỌI')
  s+=group('local',text(460,900,'Cũng có thể xử lý tệp cục bộ.',37,I))
 elif kind=='choose':
  s+=group('question',circ(460,130,95,P,O,4)+text(460,155,'VIỆC?',51,O,True))
  s+=group('branch',path('M460 225V300 M150 300H770 M150 300V370 M460 300V370 M770 300V370',B,10))
  labels=[(35,'LẶP LẠI','API',B),(345,'NHIỀU BƯỚC','CLI',O),(655,'KHÁM PHÁ','MCP',G)]
  for k,(x,word,short,c) in enumerate(labels):
   s+=group(f'choice choice{k}',rect(x,375,230,215,W,c,25)+text(x+115,438,word,30,c,True)+text(x+115,535,short,62,c,True))
  s+=group('examples',text(150,685,'Đồng bộ kho',32,B,True)+text(460,735,'Chạy quy trình',32,O,True)+text(770,685,'Hỏi vì sao?',32,G,True))
  s+=group('meter',rect(115,800,690,95,W,I,20)+text(460,863,'ĐO CÙNG TÁC VỤ RỒI CHỌN',38,I,True))
  s+=group('pick',circ(460,300,16,O,O,2))
 elif kind=='end':
  for k,(x,abbr,label_,c) in enumerate([(160,'API','Giao diện',B),(460,'CLI','Câu lệnh',O),(760,'MCP','Chuẩn nối',G)]):
   s+=group(f'role role{k}',circ(x,170,125,W,c,7)+text(x,195,abbr,64,c,True)+text(x,380,label_,42,c,True))
  s+=group('thread',path('M160 400V465H760V400 M460 400V530',B,9))
  s+=group('lock',rect(382,578,156,130,W,G,20)+path('M410 578V540a50 50 0 0 1 100 0v38',G,9)+circ(460,632,10,G,G,2)+line(460,640,460,668,G,8)+text(460,790,'ĐÚNG VIỆC · ĐÚNG QUYỀN',46,G,True))
  s+=group('final',text(460,882,'Hiểu đường đi. Làm chủ công cụ.',43,O,True))
 return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 920 920" role="img" aria-label="Sơ đồ chuyển động '+kind+'">'+s+'</svg>'
