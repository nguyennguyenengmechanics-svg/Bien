# API · CLI · MCP — Một ví dụ, ba cách làm

Bản motion graphic tiếng Việt gồm 9 cảnh, một ví dụ xuyên suốt về giảm giá. Nền kem, sơ đồ xanh–cam, headline serif và sân khấu SVG lớn.

## Render lại

Cần Node.js 22+, FFmpeg, Chrome/Chromium và HyperFrames 0.8.221. Audio và font đã có trong gói; không cần API key hay tải mô hình giọng đọc để render lại.

```sh
npm install --save-dev hyperframes@0.8.221
npx hyperframes check composition --samples 15
npx hyperframes render composition --output output/api-cli-mcp-motion.mp4 --fps 30 --quality high --workers 3
```

Khi cần, đặt HYPERFRAMES_BROWSER_PATH tới Chrome thật của máy bạn. Không cần dùng đường dẫn cache từ máy dựng.

## Sửa video

- `scenes.json`: kịch bản 9 cảnh, 36 đoạn lời đọc và phụ đề.
- `timing.json`: thời gian thực của từng đoạn audio đã tạo.
- `graphics.py`: SVG và biểu tượng tự vẽ.
- `build.py`: bố cục HTML, choreography GSAP theo timing, phụ đề và lời dẫn. Chạy `python build.py` sau khi sửa.
- `project.json` và `DESIGN.md`: thông tin, palette, typography, nhịp chuyển động.
- `make_audio.py`: mã tạo giọng và nhạc. Muốn tạo giọng mới cần sherpa-onnx, soundfile, numpy và một mô hình Việt có giấy phép phù hợp; sửa đường dẫn mô hình theo máy bạn. Đo lại timing sau khi đổi lời/giọng.

Bản nguồn nén âm thanh FLAC không mất dữ liệu. Nếu tạo lại bằng make_audio.py, chuẩn hóa narration-raw.wav tới khoảng −16 LUFS, chuyển narration.wav và music.wav sang FLAC rồi build. Có thể dùng engine giọng Việt khác nếu đo lại các đoạn.

Giữ phần ghi chú: toàn bộ cửa hàng, lệnh và kết quả là minh họa, không phải SDK/CLI có thật hay bản ghi giao dịch.
