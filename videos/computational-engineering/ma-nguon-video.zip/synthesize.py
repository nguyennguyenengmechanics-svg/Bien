import argparse,json,pathlib,subprocess
import sherpa_onnx,numpy as np,soundfile as sf
p=argparse.ArgumentParser();p.add_argument('project',type=pathlib.Path);p.add_argument('--model',type=pathlib.Path,required=True);a=p.parse_args();r=a.project;m=a.model;(r/'assets').mkdir(exist_ok=True)
cfg=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(m/'vi_VN-vais1000-medium.onnx'),tokens=str(m/'tokens.txt'),data_dir=str(m/'espeak-ng-data'),noise_scale=.5,noise_scale_w=.6),num_threads=2),max_num_sentences=1);assert cfg.validate();tts=sherpa_onnx.OfflineTts(cfg)
scenes=json.loads((r/'scenes.json').read_text());sr=22050;combined=[];frames=0
for i,s in enumerate(scenes):
 start=frames/sr;s['start']=round(start,3);s['segments']=[];pause=np.zeros(round(.65*sr),np.float32);combined.append(pause);frames+=len(pause)
 for j,text in enumerate(s['voice']):
  f=r/f'assets/voice-{i:02}-{j}.wav';key=r/f'assets/voice-{i:02}-{j}.txt'
  if f.exists() and key.exists() and key.read_text()==text:x,rate=sf.read(f,dtype='float32')
  else:
   v=tts.generate(text,sid=0,speed=.88);x=np.array(v.samples,np.float32);rate=v.sample_rate;sf.write(f,x,rate);key.write_text(text)
  assert rate==sr and len(x)>sr/2;s['segments'].append(dict(start=round(frames/sr,3),duration=round(len(x)/sr,3),text=s.get('captions',s['voice'])[j]));combined.append(x);frames+=len(x);gap=np.zeros(round(.32*sr),np.float32);combined.append(gap);frames+=len(gap)
 pause=np.zeros(round(.65*sr),np.float32);combined.append(pause);frames+=len(pause);s['duration']=round(frames/sr-start,3);print(r.name,i,round(s['duration'],2),flush=True)
(r/'timing.json').write_text(json.dumps(scenes,ensure_ascii=False,indent=2));sf.write(r/'assets/narration-raw.wav',np.concatenate(combined),sr)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(r/'assets/narration-raw.wav'),'-af','loudnorm=I=-16:TP=-2:LRA=7','-ar','22050',str(r/'composition/assets/narration.wav')],check=True)
print('TOTAL',frames/sr,flush=True)
