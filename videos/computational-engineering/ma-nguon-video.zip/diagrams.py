# Original schematic artwork. Never solver output or stock imagery.
blue='#0A527B';cream='#F1F0E4'
def wrapped(x,y,value,width=330,size=30,color=ink,bold=False,cls=''):
 words=value.split();lines=[];row='';limit=max(6,int(width/(size*.56)))
 for word in words:
  if row and len(row+' '+word)>limit:lines.append(row);row=word
  else:row=(row+' '+word).strip()
 if row:lines.append(row)
 return ''.join(text(x,y+j*(size+8),v,size,color,bold=bold,cls=cls)for j,v in enumerate(lines))
def arr(x1,y1,x2,y2,i,c=blue,cls=''):
 key='r'if c==red else 'g'if c==green else 'b'
 return line(x1,y1,x2,y2,c,8,f'marker-end="url(#a{i}{key})" class="{cls}"')
def group(body,cls='node'):return f'<g class="{cls}">{body}</g>'
def box(x,y,w,h,title,subtitle='',c=blue):
 title_svg=wrapped(x+w/2,y+45,title,w-30,32,c,True);sy=max(100,45+(title_svg.count('<text')-1)*40+37)
 return group(rect(x,y,w,h,'#FFFFFF',c,16)+title_svg+(wrapped(x+w/2,y+sy,subtitle,w-30,28,ink)if subtitle else ''))
def icon(name,x,y,c=blue,scale=1):
 # Icons live in an original 120 x 120 coordinate system.
 def p(d,w=6):return path(d,c,w)
 q=''
 if name=='gear':
  q='<circle cx="60" cy="60" r="35" fill="none" stroke="'+c+'" stroke-width="9"/><circle cx="60" cy="60" r="12" fill="none" stroke="'+c+'" stroke-width="6"/>'
  for a,b,d,e in [(60,4,60,21),(60,99,60,116),(4,60,21,60),(99,60,116,60),(20,20,32,32),(88,88,100,100),(20,100,32,88),(88,32,100,20)]:q+=line(a,b,d,e,c,9)
 elif name=='flask':q=p('M42 8 H78 M47 8 V45 L18 94 Q12 110 30 110 H90 Q108 110 102 94 L73 45 V8')+line(32,78,88,78,c,6)
 elif name in ['circuit','chip']:
  q=rect(30,30,60,60,'none',c,5)
  for a in [40,60,80]:q+=line(a,8,a,28,c,5)+line(a,92,a,112,c,5)+line(8,a,28,a,c,5)+line(92,a,112,a,c,5)
  q+=text(60,69,'I/O',25,c,bold=True)
 elif name=='code':q=p('M35 25 L7 60 L35 95 M85 25 L113 60 L85 95 M70 15 L50 105')
 elif name=='bridge':q=p('M8 90 H112 M20 90 V40 M100 90 V40 M20 40 Q60 100 100 40 M20 40 L60 15 L100 40')+line(45,75,45,90,c,4)+line(75,75,75,90,c,4)
 elif name in ['flow','conveyor']:
  q=rect(6,50,108,35,'none',c,10)+rect(20,25,24,24,'none',c,2)+rect(70,25,24,24,'none',c,2)
  for xx in [25,60,95]:q+=f'<circle cx="{xx}" cy="96" r="9" fill="none" stroke="{c}" stroke-width="5"/>'
 elif name=='robot':q=p('M25 105 H100 M45 105 V80 L72 55 L48 27 L68 8 M68 8 L92 20 M68 8 L75 35')
 elif name=='network':
  for a,b,d,e in [(60,25,20,90),(60,25,100,90),(20,90,100,90)]:q+=line(a,b,d,e,c,6)
  for xx,yy in [(60,25),(20,90),(100,90)]:q+=f'<circle cx="{xx}" cy="{yy}" r="15" fill="white" stroke="{c}" stroke-width="6"/>'
 elif name=='car':q=p('M10 85 V60 L30 52 L43 30 H80 L98 56 L112 62 V85 Z M30 52 H98')+''.join(f'<circle cx="{xx}" cy="85" r="13" fill="white" stroke="{c}" stroke-width="6"/>'for xx in[30,90])
 elif name=='plane':q=p('M60 7 L69 47 L110 72 V82 L69 67 L69 100 L87 110 V116 L60 108 L33 116 V110 L51 100 V67 L10 82 V72 L51 47 Z',4)
 elif name=='ship':q=p('M8 68 H112 L95 100 H30 Z M35 68 V36 H82 V68 M48 36 V18 H65 V36 M8 113 Q23 100 38 113 Q53 100 68 113 Q83 100 98 113')
 elif name=='heart':q=p('M60 105 C-5 65 5 5 45 22 L60 37 L75 22 C115 5 125 65 60 105 M20 60 H43 L53 43 L66 78 L78 60 H104',5)
 elif name=='plant':q=p('M60 112 V42 M60 70 Q5 70 12 15 Q57 18 60 62 M60 85 Q115 75 108 30 Q67 36 60 80 M15 114 H105')
 elif name=='water':q=p('M60 8 C30 48 15 60 18 80 C20 124 100 124 102 80 C105 60 90 48 60 8 M40 75 Q32 94 51 100',5)
 elif name=='oil':q=p('M28 110 L50 15 H75 L98 110 M18 110 H108 M44 40 H82 M38 70 H89 M50 15 H98 V70 M50 15 L15 58',5)
 elif name=='atom':
  for ang in [0,60,120]:q+=f'<ellipse cx="60" cy="60" rx="53" ry="20" transform="rotate({ang} 60 60)" fill="none" stroke="{c}" stroke-width="5"/>'
  q+=f'<circle cx="60" cy="60" r="8" fill="{c}"/>'
 elif name=='building':
  q=rect(20,8,80,104,'none',c,3)
  for yy in[25,50,75]:
   for xx in[38,64]:q+=rect(xx,yy,15,12,'none',c,1)
 elif name=='crane':q=p('M20 110 H65 M40 110 V15 M10 25 H112 L40 8 L10 25 M90 25 V72 M80 72 H100 V95 H80 Z')
 elif name=='lattice':
  for xx in[20,60,100]:q+=line(xx,20,xx,100,c,4)
  for yy in[20,60,100]:q+=line(20,yy,100,yy,c,4)
  for xx in[20,60,100]:
   for yy in[20,60,100]:q+=f'<circle cx="{xx}" cy="{yy}" r="7" fill="{c}"/>'
 return f'<g transform="translate({x} {y}) scale({scale})">{q}</g>'

def fields_svg(s,i):
 f=s['fields'];n=len(f);w=390 if n==2 else 260;gap=30;x0=(900-n*w-(n-1)*gap)/2;b=''
 for j,(title,ico,desc,example) in enumerate(f):
  x=x0+j*(w+gap);c=blue if j%2==0 else red
  body=rect(x,45,w,475,'#FFFFFF',c,18)+wrapped(x+w/2,100,title,w-26,32,c,True)+icon(ico,x+w/2-60,180,c)+wrapped(x+w/2,350,desc,w-30,29,ink,True)+wrapped(x+w/2,435,example,w-30,28,c)
  b+=group(body)
 b+=text(450,570,'Ví dụ nhiệm vụ · Phạm vi có giao thoa',28,green)
 return b

def svg(kind,i):
 s=scenes[i];defs=''.join(f'<marker id="a{i}{key}" markerWidth="22" markerHeight="22" refX="18" refY="11" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0 L22 11 L0 22 Z" fill="{c}"/></marker>'for key,c in [('r',red),('b',blue),('g',green)])
 b=''
 if kind in ['fields2','fields3']:b=fields_svg(s,i)
 elif kind=='hook':
  b+=rect(100,70,700,150,cream,ink,18)+text(450,128,'HÌNH ẢNH ĐẸP',42,ink,bold=True)+text(450,185,'≠ kết quả đã được kiểm chứng',33,red,bold=True)
  b+=arr(450,240,450,310,i,red)+box(100,330,310,160,'Mô hình vật lý','Giả thiết · Điều kiện biên',blue)+box(490,330,310,160,'Lời giải số','Thuật toán · Sai số',red)+text(450,565,'Phải kiểm tra cả hai',34,green,bold=True)
 elif kind in ['intersection','curriculum']:
  names=['TOÁN','VẬT LÝ','LẬP TRÌNH'];subs=['Phương trình · Sai số','Quy luật · Giả thiết','Thuật toán · Kiểm thử']
  for j,(xx,yy) in enumerate([(45,65),(495,65),(270,360)]):
   c=[blue,red,green][j];b+=box(xx,yy,360,145,names[j],subs[j],c)
  b+=arr(330,220,340,270,i,blue)+arr(570,220,560,270,i,red)+arr(450,345,450,328,i,green)+rect(350,250,200,70,cream,ink,10)+text(450,295,'MÔ HÌNH',35,ink,bold=True)
  if kind=='curriculum':b+=text(450,560,'Đọc đề cương của từng chương trình',28,green)
 elif kind=='methods':
  for x,y,t,sub,c in [(70,50,'LÝ THUYẾT','Quan hệ · Giả thiết',blue),(490,50,'THỬ NGHIỆM','Quan sát hệ thật',red),(280,365,'TÍNH TOÁN','Khảo sát phương án',green)]:b+=box(x,y,340,140,t,sub,c)
  b+=arr(410,120,480,120,i,blue)+arr(610,220,540,340,i,red)+arr(330,340,240,220,i,green)+text(450,295,'PHỐI HỢP',32,ink,bold=True)
 elif kind in ['pipeline','roadmap','choice']:
  items=([('CÂU HỎI','Đại lượng cần biết'),('MÔ HÌNH','Giả thiết · Điều kiện biên'),('LỜI GIẢI','Rời rạc hóa · Thuật toán'),('KIỂM TRA','Sai số · Phạm vi dùng')]if kind=='pipeline'else [('HIỂU VẬT LÝ','Thanh chịu kéo 1D'),('VIẾT CHƯƠNG TRÌNH','Lập hệ · Giải'),('ĐỐI CHIẾU','Nghiệm giải tích'),('GIẢI THÍCH','Sai số · Giới hạn')])
  if kind=='choice':items=[('SỞ THÍCH','Bạn muốn giải vấn đề gì?'),('ĐỀ CƯƠNG','Nền tảng · Đồ án'),('DỰ ÁN NHỎ','Thử làm, không chỉ đọc'),('VAI TRÒ','Đối chiếu mô tả công việc')]
  for j,(t,sub) in enumerate(items):
   x=75 if j%2==0 else 495;y=45+(j//2)*290;c=blue if j%2==0 else red;b+=box(x,y,330,175,t,sub,c)
  b+=arr(415,130,475,130,i,blue)+arr(660,235,660,305,i,red)+arr(480,420,425,420,i,green)
  b+=text(450,575,'Vòng lặp cải tiến, không phải làm một lần',28,green)
 elif kind=='fea_cfd':
  b+=text(230,70,'FEA · Kết cấu',34,blue,bold=True)+text(675,70,'CFD · Dòng chảy',34,red,bold=True)
  b+=rect(65,180,330,190,cream,blue,3)
  for xx in[65,175,285,395]:b+=line(xx,180,xx,370,blue,3)
  for yy in[180,275,370]:b+=line(65,yy,395,yy,blue,3)
  for xx in[65,175,285,395]:
   for yy in[180,275,370]:b+=f'<circle cx="{xx}" cy="{yy}" r="7" fill="{blue}"/>'
  b+=arr(395,275,450,275,i,red)+text(230,445,'Nút · Phần tử · Tải',29,blue,bold=True)
  b+=rect(505,170,330,210,'#FFFFFF',red,3)
  for xx in[560,615,670,725,780]:b+=line(xx,170,xx,380,red,2)
  for yy in[240,310]:b+=line(505,yy,835,yy,red,2)
  for yy in[210,275,345]:b+=arr(530,yy,805,yy,i,red)+f'<circle class="fluid-dot" cx="540" cy="{yy}" r="10" fill="{blue}"/>'
  b+=text(675,445,'Bảo toàn · Rời rạc',29,red,bold=True)+text(450,555,'Sơ đồ nguyên lý · Không phải kết quả FEA/CFD',28,green)
 elif kind=='bar_example':
  b+=text(450,60,'VÍ DỤ GIẢ ĐỊNH · ĐÀN HỒI TUYẾN TÍNH',29,green,bold=True)+text(450,112,'L = 1 m     A = 100 mm²     E = 200 GPa',29,ink)
  b+=rect(155,205,35,160,pale,ink,0)+rect(200,245,520,70,'none',ink,0,extra='stroke-dasharray="10 8"')+rect(200,245,570,70,'#DCE8EF',blue,0,extra='class="extension"')
  for xx,label,cl in [(200,'0','fixednode'),(485,'0,25 mm','midnode'),(770,'0,50 mm','endnode')]:b+=f'<g class="{cl}"><circle cx="{xx}" cy="280" r="10" fill="{blue}"/>'+text(xx,375,label,29,blue,bold=True)+'</g>'
  b+=arr(785,280,865,280,i,red)+text(790,208,'F = 10 kN',28,red,bold=True)+arr(150,280,70,280,i,blue)+text(450,455,'u = FL/(EA) = 0,50 mm',39,red,bold=True)+text(450,510,'σ = F/A = 100 MPa',32,ink,bold=True)+text(450,565,'Hai phần tử thanh · Biến dạng phóng đại',28,green)
 elif kind=='verification':
  b+=box(45,50,390,440,'VERIFICATION','Giải phương trình đúng?',blue)+box(465,50,390,440,'VALIDATION','Mô hình phù hợp hệ thật?',red)
  b+=icon('code',180,215,blue)+icon('gear',600,215,red)+text(240,385,'Nghiệm giải tích',29,blue,bold=True)+text(240,440,'u = 0,50 mm',32,blue,bold=True)+text(660,385,'Dữ liệu đo phù hợp',29,red,bold=True)+text(660,440,'Xét cả bất định',30,red,bold=True)+text(450,565,'Hai câu hỏi khác nhau, đều cần thiết',28,green)
 elif kind=='applications':
  for j,(title,ico,sub) in enumerate([('Ô tô · Hàng không','car','Kết cấu · Khí động'),('Năng lượng','atom','Nhiệt · Vận hành'),('Y sinh','heart','Cơ sinh học · Thuật toán')]):
   y=35+j*185;c=[blue,red,green][j];b+=group(rect(45,y,810,155,'#FFFFFF',c,14)+icon(ico,70,y+20,c,.9)+text(520,y+55,title,34,c,bold=True)+text(520,y+110,sub,30,ink))
 elif kind=='careers':
  for j,(t,sub) in enumerate([('CAE / FEA / CFD','Phân tích theo loại bài toán'),('Modeling & Simulation','Xây dựng · Kiểm tra mô hình'),('Scientific Software','Thuật toán · Phần mềm khoa học')]):b+=box(60,30+j*185,780,150,t,sub,[blue,red,green][j])
 elif kind=='field_map':
  cpos=[(35,35,'CƠ KHÍ'),(495,35,'KỸ THUẬT HÓA'),(35,225,'ĐIỆN'),(495,225,'PHẦN MỀM'),(35,415,'XÂY DỰNG'),(495,415,'CÔNG NGHIỆP')]
  for j,(xx,yy,t) in enumerate(cpos):
   c=blue if j%2==0 else red;b+=group(rect(xx,yy,370,115,'#FFFFFF',c,14)+text(xx+185,yy+72,t,32,c,bold=True))
  b+=line(450,90,450,475,green,9)
  for y in[90,280,470]:b+=line(410,y,490,y,green,8)
  b+=text(450,580,'Sáu nhóm trong cách trình bày của nguồn',28,green)
 elif kind=='finance':
  for x,y,t,sub,c in [(60,45,'TOÁN','Mô hình · Tối ưu',blue),(480,45,'THỐNG KÊ','Dữ liệu · Bất định',red),(60,325,'LẬP TRÌNH','Thuật toán · Công cụ',red),(480,325,'TÀI CHÍNH','Định giá · Rủi ro',blue)]:b+=box(x,y,360,165,t,sub,c)
  b+=arr(430,130,465,130,i,green)+arr(430,410,465,410,i,green)+text(450,570,'Kiểm tra giả thiết và dữ liệu của mô hình',28,green)
 else:raise ValueError(kind)
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 600" role="img" aria-label="{E(s["title"])}"><defs>{defs}</defs>{b}</svg>'

def animate(scene,sel):
 st=scene['start'];kind=scene['diagram'];a=[];sel='#'+sel
 if kind=='bar_example':
  a+=[f'tl.from("{sel} .extension",{{scaleX:{520/570},transformOrigin:"left center",duration:2.4,ease:"sine.inOut"}},{st+3});',f'tl.from("{sel} .midnode",{{x:-25,duration:2.4,ease:"sine.inOut"}},{st+3});',f'tl.from("{sel} .endnode",{{x:-50,duration:2.4,ease:"sine.inOut"}},{st+3});']
 if kind=='fea_cfd':a+=[f'tl.to("{sel} .fluid-dot",{{x:240,duration:2.2,repeat:3,repeatDelay:.3,ease:"none"}},{st+3});']
 return a
