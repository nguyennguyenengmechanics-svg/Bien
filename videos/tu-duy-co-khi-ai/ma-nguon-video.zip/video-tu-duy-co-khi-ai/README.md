# Tư duy thiết kế cơ khí trong kỷ nguyên AI

Nguồn chỉnh sửa: index.html. Thiết kế: DESIGN.md. Font, giọng đọc và nhạc đi kèm assets.
Cần Node.js 22+, Chromium và FFmpeg; không cần API key để xuất lại.

```bash
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 render --output final.mp4 --fps 30 --quality high --workers 3
```

Xem GHI-CHU.txt cho nguồn nội dung và attribution. Sơ đồ chỉ minh họa lập luận, không phải kết quả thử nghiệm hay mô phỏng kỹ thuật.
