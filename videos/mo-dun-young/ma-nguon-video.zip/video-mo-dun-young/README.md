# Mô đun Young: từ nguyên tử đến độ võng

Nguồn chỉnh sửa: index.html. Font, giọng đọc và nhạc kèm assets. Cần Node.js 22+, Chromium và FFmpeg, không cần API key để xuất lại.

```bash
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 render --output final.mp4 --fps 30 --quality high --workers 3
```

Xem DESIGN.md về phong cách; GHI-CHU.txt về giả thiết kỹ thuật, nguồn và attribution. Minh họa nguyên tử và đồ thị là định tính, không phải mô phỏng thực hay dữ liệu đo.
