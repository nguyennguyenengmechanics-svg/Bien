# Video các thuyết phá hủy trong cơ học vật liệu

1080×1920, 30 fps, khoảng 4 phút 31 giây. HTML/SVG + GSAP; giọng Việt tổng hợp và nhạc nền. Các tài nguyên để render đều có trong assets.

Dùng HyperFrames CLI 0.9.0 trong thư mục này:

```sh
npx hyperframes preview
npx hyperframes check --samples 15
npx hyperframes render . --output cac-thuyet-pha-huy.mp4 --fps 30 --quality high
```

Nếu có Chromium hệ thống, đặt HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium. Mã nguồn ở thư mục gốc gồm build.py, diagrams.py, scenes.json, timing.json và music.py. Chạy python build.py từ thư mục gốc để dựng lại HTML. Không cần mô hình TTS để render lại video từ HTML và WAV có sẵn.

Xem GHI-CHU.txt về phạm vi mô hình, số liệu giả định và giấy phép.
