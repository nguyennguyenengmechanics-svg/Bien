blue='#0A527B'
def svg(kind,i):
 a=f'<svg viewBox="0 0 900 570"><defs><marker id="a{i}" markerWidth="20" markerHeight="20" refX="18" refY="10" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L0,20 L20,10 z" fill="{red}"/></marker></defs>'
 def card(x,y,w,h,title,sub='',c=blue):
  return '<g class="node">'+rect(x,y,w,h,'#E1EFF6' if c==blue else '#FFE1BD',c,10)+rect(x,y,10,h,c,'none',2)+text(x+w/2,y+43,title,31,c,bold=True)+(text(x+w/2,y+86,sub,28)if sub else '')+'</g>'
 def branch(x1,y1,x2,y2,c=blue):return line(x1,y1,x2,y2,c,9)
 def cube(x,y,c=blue):
  return '<g class="cube">'+path(f'M{x} {y} l130 0 60 -45 -130 0 Z',c,4,'#DCEBF1')+path(f'M{x+130} {y} l60 -45 0 130 -60 45 Z',c,4,'#C1D5DC')+rect(x,y,130,130,'#E1EFF6',c,0)+'</g>'
 def note(s):return text(450,545,s,28,green,bold=True)
 if kind=='intro':
  a+=card(55,30,360,95,'KIM LOẠI DẺO',c=blue)+card(485,30,360,95,'VẬT LIỆU GIÒN',c=red)
  a+='<g class="deform">'+path('M120 210 H350 V325 H120 Z',blue,5,'#DCEBF1')+'</g>'
  a+=path('M550 210 H650 L630 250 660 285 640 325 H550 Z',red,5,'#FFE1BD')+path('M680 210 H780 V325 H670 L690 285 660 250 Z',red,5,'#FFE1BD',extra='class="broken"')
  a+=text(235,420,'BIẾN DẠNG DƯ',35,blue,bold=True)+text(665,420,'NỨT GÃY',35,red,bold=True)+note('Mất chức năng có thể xảy ra trước khi đứt')
 elif kind=='limits':
  a+=line(100,420,800,420)+line(100,420,100,75)+text(65,85,'σ',32,bold=True)+text(810,450,'ε',32,bold=True)
  a+=path('M100 420 L270 180 C340 145 400 135 470 120 C530 110 570 145 610 180',blue,8,extra='class="curve"')+path('M100 420 L270 180 L520 65',red,7,extra='class="curve"')
  a+=f'<circle cx="270" cy="180" r="12" fill="{blue}"/>'+text(320,245,'σy: bắt đầu chảy',30,blue,'start',True)+text(585,85,'Giòn: nứt gãy',29,red,'start',True)+text(555,150,'Dẻo',29,blue,'start',True)
  a+=note('Đường cong định tính · Không phải dữ liệu thử')
 elif kind=='principal':
  a+=cube(345,175)
  a+=arrow(500,240,730,240,i)+arrow(340,240,150,240,i)+arrow(410,165,410,60,i)+arrow(410,320,410,425,i)+arrow(535,145,650,65,i)
  a+=text(750,230,'σ1',37,red,bold=True)+text(450,65,'σ2',37,red,bold=True)+text(695,65,'σ3',37,red,bold=True)
  a+=card(170,450,560,95,'σ1 ≥ σ2 ≥ σ3 · Kéo + / Nén −')
 elif kind=='split':
  a+=card(35,30,830,95,'ỨNG SUẤT = THỦY TĨNH + LỆCH')
  a+='<g class="hydro">'+cube(155,205,blue)+'</g><g class="dev">'+path('M535 235 L720 190 L755 335 L570 380 Z',red,6,'#FFE1BD')+'</g>'
  a+=text(450,290,'+',56,ink,bold=True)+text(240,430,'σm · I',38,blue,bold=True)+text(650,430,'si = σi − σm',36,red,bold=True)+note('Trong mô hình kim loại dẻo đẳng hướng phù hợp')
 elif kind=='tresca':
  a+=text(450,55,'VÍ DỤ GIẢ ĐỊNH · ĐƠN VỊ MPa',30,blue,bold=True)
  for x,t,v,c in [(45,'σ1','+120',blue),(335,'σ2','+40',blue),(625,'σ3','−80',red)]:a+=card(x,100,230,125,t,v,c)
  a+=branch(160,245,160,285)+branch(740,245,740,285,red)+branch(160,285,740,285,red)
  a+=text(450,355,'σT = 120 − (−80) = 200 MPa',39,red,bold=True)+text(450,425,'σy = 250 MPa',34,blue,bold=True)+text(450,490,'nT = 250 / 200 = 1,25',38,blue,bold=True)
  a+=text(450,550,'Chỉ là hệ số dự trữ theo mô hình',28,green,bold=True)
 elif kind=='mises':
  a+=text(450,55,'CÙNG VÍ DỤ · σy = 250 MPa',30,blue,bold=True)
  a+=card(75,105,750,100,'Các hiệu: 80 · 120 · 200 MPa')
  a+=text(450,280,'σVM = √[(80² + 120² + 200²)/2]',36,ink,bold=True)+text(450,370,'σVM ≈ 174 MPa',48,red,bold=True)+text(450,465,'nVM ≈ 250 / 174 ≈ 1,43',38,blue,bold=True)+note('Số liệu giả định · Không phải chứng nhận thiết kế')
 elif kind=='envelopes':
  cx=450;cy=290;scale=175
  def pt(x,y):return(cx+scale*x,cy-scale*y)
  a+=line(120,cy,790,cy,ink,3)+line(cx,510,cx,65,ink,3)+text(810,cy+10,'σA/σy',28,blue,bold=True)+text(cx+20,45,'σB/σy',28,blue,'start',True)
  points=[]
  for j in range(241):
   t=j*2*math.pi/240;x=math.cos(t);y=math.sin(t);v=math.sqrt(x*x-x*y+y*y);points.append(pt(x/v,y/v))
  a+=path('M'+' L'.join(f'{x:.2f} {y:.2f}'for x,y in points)+' Z',blue,7,extra='class="curve"')
  q=[pt(x,y) for x,y in [(1,1),(0,1),(-1,0),(-1,-1),(0,-1),(1,0)]]
  a+=path('M'+' L'.join(f'{x} {y}'for x,y in q)+' Z',red,7,extra='class="curve"')
  a+=text(145,90,'von Mises',30,blue,bold=True)+text(735,450,'Tresca',30,red,bold=True)+text(625,108,'(1; 1)',28,ink,bold=True)+note('σC = 0 · Phải xét cả ứng suất thứ ba')
 elif kind=='shear':
  a+=text(450,55,'CẮT THUẦN TÚY · σy = 250 MPa',30,blue,bold=True)+text(450,130,'Ứng suất chính: (τ, 0, −τ)',36,ink,bold=True)
  a+=text(75,240,'Tresca',31,red,'start',True)+rect(75,265,500,66,'#FFE1BD',red)+text(605,310,'125 MPa',33,red,'start',True)
  a+=text(75,390,'von Mises',31,blue,'start',True)+rect(75,415,577.35,66,'#DCEBF1',blue)+text(665,459,'144 MPa',31,blue,'start',True)
  a+=note('(144,34 / 125 − 1) × 100% ≈ 15,5%')
 elif kind=='brittle':
  a+=card(60,45,350,110,'KÉO','Sut',red)+card(490,45,350,110,'NÉN','Suc',blue)
  a+=path('M150 230 H240 L220 270 250 300 230 355 H150 Z',red,5,'#FFE1BD')+path('M270 230 H340 V355 H260 L280 300 250 270 Z',red,5,'#FFE1BD')
  a+=rect(570,230,160,125,'#DCEBF1',blue)+arrow(650,190,650,225,i)+arrow(650,395,650,360,i)
  a+=text(245,435,'Nứt mở khi kéo',31,red,bold=True)+text(655,435,'Nén có thể đóng nứt',29,blue,bold=True)+note('Nhiều vật liệu giòn: Suc > Sut · Cần dữ liệu thử')
 elif kind=='mohr':
  a+=text(450,50,'MIỀN KÉO–NÉN: σ1 ≥ 0 ≥ σ3',30,blue,bold=True)
  a+=card(55,90,790,100,'Sut = 100 · Suc = 300 MPa')
  a+=text(450,255,'σ1 = 40 · σ3 = −120 MPa',35,ink,bold=True)+text(450,335,'ICM = 40/100 − (−120)/300',37,ink,bold=True)+text(450,420,'ICM = 0,4 + 0,4 = 0,8',43,red,bold=True)+note('Ví dụ giả định · Chưa áp hệ số an toàn yêu cầu')
 elif kind=='closing':
  a+=card(235,20,430,95,'CƠ CHẾ HỎNG')+branch(450,115,450,155)+branch(220,155,680,155)+branch(220,155,220,190)+branch(680,155,680,190,red)
  a+=card(45,190,350,125,'CHẢY DẺO','Tresca / von Mises')+card(505,190,350,125,'NỨT GIÒN','Rankine / nhóm Mohr',red)
  a+=branch(220,315,220,365)+branch(680,315,680,365,red)+branch(220,365,680,365)+branch(450,365,450,395)
  a+=card(145,395,610,105,'DỮ LIỆU · HỆ SỐ AN TOÀN','Kiểm chứng phạm vi áp dụng')+note('Kiểm tra riêng: mỏi · nứt · mất ổn định')
 return a+'</svg>'
