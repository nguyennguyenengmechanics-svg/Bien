# 22 lĩnh vực kỹ thuật: hiểu đúng để chọn ngành

Video học thuật tiếng Việt,1080×1920,30fps, khoảng5phút11giây. Nền kem, tiêu đề serif, từ khóa đậm/cam, sơ đồ có nhánh xanh–cam. Sơ đồ minh họa, số giả định được ghi rõ.

## Render lại

Tất cả tài nguyên render có trong composition/assets, gồm font, GSAP, narration.wav và music.wav. Không cần mô hình TTS để render.

```sh
python build.py
npx hyperframes check composition --samples 12
npx hyperframes render composition --output output/engineering-fields.mp4 --fps 30 --quality high --workers 2
```

Đặt HYPERFRAMES_BROWSER_PATH tới trình duyệt đã cài nếu cần. Dùng Node22+, HyperFrames0.9.0 và FFmpeg. Các dữ liệu thời gian có sẵn trong timing.json được đo từ từng tệp giọng thực. scenes.json là kịch bản và nội dung hình; diagrams.py tạo SVG; build.py ghép HTML/GSAP và phụ đề.

Nếu sửa lời đọc, cần cài sherpa-onnx1.12.40, numpy và soundfile; cung cấp thư mục mô hình vi_VN-vais1000-medium có model/tokens/espeak-ng-data, rồi chạy:

```sh
python synthesize.py . --model /duong-dan/mo-hinh
python music.py
python build.py
```

synthesize.py kiểm tra văn bản của từng đoạn trong cache; chỉ tái dùng WAV khi nội dung giống nhau, sau đó tính lại toàn bộ timing. Mô hình không được đóng gói. Xem GHI-CHU.txt và KIEM-TRA.md trong output về nguồn, giả thiết và kết quả kiểm tra. Không gọi các sơ đồ nguyên lý là thí nghiệm hoặc kết quả FEA/CFD thực.
