import pathlib,json,html,re
R=pathlib.Path(__file__).parent;P=R/'composition';sc=json.load(open(R/'timing.json'));T=round(sc[-1]['start']+sc[-1]['duration'],3);E=html.escape
shot=P/'assets/visit-japan-web-thumb.png';has_shot=shot.exists()
def rich(t,keys):
 keys=[k for k in sorted(keys,key=len,reverse=True)if k.casefold()in t.casefold()][:2];s=E(t)
 return re.sub('|'.join(re.escape(E(k))for k in keys),lambda m:'<strong>'+m.group(0)+'</strong>',s,flags=re.I)if keys else s
camera='<svg viewBox="0 0 120 90" aria-hidden="true"><path d="M15 23 H36 L44 10 H76 L84 23 H105 V78 H15 Z" fill="none" stroke="#31746A" stroke-width="6"/><circle cx="60" cy="49" r="18" fill="none" stroke="#31746A" stroke-width="6"/><path d="M13 8 L108 84" stroke="#BA5D43" stroke-width="8"/></svg>'
css=(R/'theme.css').read_text()
parts=['<!DOCTYPE html><html lang="vi"><head><meta charset="utf-8"><title>Hành trình thực tập METI | Tân Sơn Nhất → Narita</title><script src="assets/gsap.min.js"></script><style>'+css+'</style></head><body>',f'<div id="root" data-composition-id="main" data-width="1080" data-height="1920" data-start="0" data-duration="{T}"><video id="footage" class="clip" src="assets/base.mp4" data-start="0" data-duration="{T}" data-track-index="0" muted playsinline></video>'];an=[];srt=[];ci=0
for i,s in enumerate(sc):
 ident=f's{i}';start=s['start'];end=start+s['duration'];k=s['kind'];body=''
 if k=='intro':body='<div class="chip"><strong>TÂN SƠN NHẤT → NARITA</strong><div class="clock-note">Bắt đầu hành trình thực tập tại Nhật Bản</div></div>'
 elif k=='meti':body='<div class="chip"><strong>METI Japan Internship</strong></div>'
 elif k=='departure':body='<div class="chip"><strong>GIỜ VIỆT NAM · UTC+7</strong><div class="clock-note">Tân Sơn Nhất → Narita</div></div>'
 elif k=='arrival':body='<div class="chip"><strong>GIỜ NHẬT BẢN · UTC+9</strong><div class="clock-note">Narita, Nhật Bản</div><div class="clock-note">Nhật Bản đi trước Việt Nam 2 tiếng</div></div>'
 elif k=='signs':
  body='<div class="guide"><div class="label">BIỂN CHỈ DẪN TRONG HÀNH TRÌNH</div><div class="sign-image"><img src="assets/arrivals-sign.jpg"/><div class="arrivals-box"></div></div><div class="guide-row good">ARRIVALS <span>→ Khu vực đến</span></div><div class="guide-row">DOMESTIC <span>· Nội địa</span></div><div class="guide-row">TRANSIT / TRANSFER <span>· Nối chuyến</span></div><div class="route-note">Nhập cảnh tại Narita: theo hướng Arrivals.</div></div>'
 elif k=='immigration':
  body='<div class="no-film" id="immigration-card">'+camera+'<div class="big">Khu vực làm thủ tục<br>không ghi hình</div><div class="small">Phần này được kể lại bằng lời dẫn.</div><div class="steps"><div class="active">Nhập cảnh</div><div>Hành lý</div><div>Hải quan</div></div></div>'
  screen='<img class="mini-site-shot" src="assets/visit-japan-web-thumb.png"/>' if has_shot else ''
  body+='<div class="mini-vjw" id="visit-card"><div class="mini-site-title">THÔNG TIN PHỤ</div><div class="mini-name">Visit Japan Web</div>'+screen+'<div class="mini-copy">Khai trước · Chuẩn bị mã QR</div><div class="mini-url">www.vjw.digital.go.jp</div><div class="mini-copy">Hình minh họa giao diện</div></div>'
 elif k=='baggage':body='<div class="chip"><strong>NHẬN HÀNH LÝ</strong><div class="clock-note">Sau bước nhập cảnh</div></div>'
 elif k=='customs':body='<div class="no-film" id="customs-card">'+camera+'<div class="big">Hải quan<br>không ghi hình</div><div class="steps"><div>Nhập cảnh</div><div>Hành lý</div><div class="active">Hải quan</div></div><div class="small">Hoàn tất rồi ra khu vực đón xe.</div></div>'
 elif k=='friends':body='<div class="friends-photo"><img id="friends-image" src="assets/friends-safe.jpg"/></div><div class="friends-note">METI JAPAN INTERNSHIP<br><strong>Khép lại ngày đầu tiên.</strong></div>'
 elif k=='closing':body='<div class="chip"><strong>METI JAPAN INTERNSHIP</strong><div class="clock-note">Cơ hội học hỏi và trải nghiệm tại Nhật Bản</div></div>'
 caps=''
 for j,seg in enumerate(s['segments']):
  caps+=f'<div class="caption" id="cap{i}-{j}" style="opacity:0"><span>{rich(seg["text"],s["highlights"])}</span></div>'
  an.extend([f'tl.to("#cap{i}-{j}",{{opacity:1,duration:.13}},{seg["start"]});',f'tl.to("#cap{i}-{j}",{{opacity:0,duration:.13}},{seg["start"]+seg["duration"]+.12});',f'tl.set("#cap{i}-{j}",{{opacity:0}},{seg["start"]+seg["duration"]+.25});'])
  def ts(t):
   m=round(t*1000);return f'{m//3600000:02}:{m//60000%60:02}:{m//1000%60:02},{m%1000:03}'
  ci+=1;srt.append(f'{ci}\n{ts(seg["start"])} --> {ts(seg["start"]+seg["duration"])}\n{seg["text"]}\n')
 parts+=[f'<section class="scene" data-layout-allow-overflow id="{ident}" style="opacity:{1 if i==0 else 0};z-index:{i+1}"><div class="scene-content"><div class="brand"><span>Nhật ký thực tập METI</span><span>SGN → NRT</span></div><div class="head"><div class="tag">{E(s["tag"])}</div><h1 class="headline"><span>{rich(s["title"],s["em"])}</span></h1></div><div class="stage">{body}</div><div class="caption-zone">{caps}</div><div class="footer"><span>METI Japan Internship · Ngày 01</span><span>{i+1:02} / {len(sc):02}</span></div></div></section>']
 if i:
  parts+=[f'<div class="chapter-wipe" id="wipe{i}"></div>'];an+=[f'tl.fromTo("#wipe{i}",{{x:-1080}},{{x:1080,duration:.44,ease:"power2.inOut",immediateRender:false}},{start-.22});',f'tl.set("#s{i-1}",{{opacity:0}},{start});',f'tl.set("#{ident}",{{opacity:1}},{start});']
 an+=[f'tl.from("#{ident} .brand",{{y:-10,opacity:0,duration:.5,ease:"power2.out"}},{start+.15});',f'tl.from("#{ident} .head",{{x:-30,opacity:0,duration:.7,ease:"power3.out"}},{start+.25});',f'tl.from("#{ident} .stage",{{y:20,opacity:0,duration:.7,ease:"sine.out"}},{start+.5});',f'tl.from("#{ident} .footer",{{opacity:0,duration:.5,ease:"sine.out"}},{start+.4});']
 if i==0:an=[a for a in an if '#s0 .head'not in a]
 if k=='signs':
  an+=[f'tl.from("#{ident} .guide-row",{{x:25,opacity:0,stagger:.35,duration:.6,ease:"power3.out"}},{start+1.4});']
 if k=='immigration':
  v=s['segments'][1]['start']-.15
  an+=[f'tl.fromTo("#visit-card",{{opacity:0,y:22}},{{opacity:1,y:0,duration:.6,ease:"power3.out",immediateRender:false}},{v+.1});']

 if k=='friends':an+=[f'tl.from("#friends-image",{{scale:.96,opacity:0,duration:1.1,ease:"sine.out"}},{start+.3});']
 if k=='customs':an+=[f'tl.to("#customs-card",{{opacity:0,duration:.3}},{end-1.9});']
parts+=[f'<div class="progress"><div id="progress" class="fill"></div></div><audio id="voiceover" src="assets/narration.wav" data-start="0" data-duration="{T}" data-track-index="2" data-volume="1"></audio><audio id="music" src="assets/music.wav" data-start="0" data-duration="{T}" data-track-index="3" data-volume="1"></audio></div>','<script>window.__timelines=window.__timelines||{};const tl=gsap.timeline({paused:true});'+'\n'.join(an)+f'\ntl.from("#progress",{{scaleX:0,duration:{T},ease:"none"}},0);window.__timelines.main=tl;</script></body></html>']
(P/'index.html').write_text(''.join(parts));(R/'output/phu-de.vi.srt').write_text('\n'.join(srt));(R/'output/loi-doc-tts.txt').write_text('\n\n'.join(s['tag']+'\n'+' '.join(s['voice'])for s in sc));(R/'output/loi-dan-hien-thi.txt').write_text('\n\n'.join(s['tag']+'\n'+' '.join(s.get('captions',s['voice']))for s in sc));(R/'output/loi-dan.txt').write_text((R/'output/loi-dan-hien-thi.txt').read_text());print('Built',T,'seconds; user website screenshot:',has_shot)
