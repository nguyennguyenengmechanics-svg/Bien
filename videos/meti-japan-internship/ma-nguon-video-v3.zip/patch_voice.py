import pathlib,json,subprocess
import numpy as np,soundfile as sf,sherpa_onnx
r=pathlib.Path(__file__).parent;m=pathlib.Path('/workspace/meti-narita/assets/vits-piper-vi_VN-vais1000-medium')
cfg=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(m/'vi_VN-vais1000-medium.onnx'),tokens=str(m/'tokens.txt'),data_dir=str(m/'espeak-ng-data'),noise_scale=.5,noise_scale_w=.6),num_threads=2),max_num_sentences=1)
tts=sherpa_onnx.OfflineTts(cfg)
p=r/'composition/assets/narration.wav';audio,sr=sf.read(p,dtype='float32');s=next(x for x in json.loads((r/'timing.json').read_text()) if x['kind']=='signs')
for j,(seg,text) in enumerate(zip(s['segments'],s['voice'])):
 a=tts.generate(text,sid=0,speed=.91);raw=r/f'assets/corrected-{j}.wav';fit=r/f'assets/fitted-{j}.wav';sf.write(raw,np.array(a.samples),a.sample_rate)
 speed=(len(a.samples)/a.sample_rate)/seg['duration'];subprocess.run(['ffmpeg','-v','error','-y','-i',str(raw),'-af',f'atempo={speed}', '-ar',str(sr),str(fit)],check=True)
 x,_=sf.read(fit,dtype='float32');start=round(seg['start']*sr);n=round(seg['duration']*sr);old=audio[start:start+n];x=np.pad(x,(0,max(0,n-len(x))))[:n];gain=np.sqrt(np.mean(old**2))/(np.sqrt(np.mean(x**2))+1e-9);x*=gain
 audio[start:start+n]=np.clip(x,-.98,.98);print(j,round(speed,3),flush=True)
sf.write(p,audio,sr)
