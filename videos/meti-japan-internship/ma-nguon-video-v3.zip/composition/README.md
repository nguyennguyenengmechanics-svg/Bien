# Vlog METI — Thiết kế v2

1080×1920,30fps, khoảng1phút31giây. Be Vietnam Pro, nền kem và xanh ngọc; nội dung/giọng giữ như bản đã duyệt.

Trong thư mục composition, dùng HyperFrames0.9.0 và FFmpeg:

```sh
npx hyperframes check --samples 15
npx hyperframes render . --output meti-japan-internship-ngay-1-v2.mp4 --fps 30 --quality high
```

Có thể đặt HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium nếu dùng Chromium hệ thống. Mọi tài nguyên phát lại cần thiết có trong assets; không cần mô hình TTS để render lại.

build.py ở gốc đọc theme.css và timing.json. Sửa theme.css để đổi kiểu chữ, bảng màu và lớp nền. Video nền đã che mã và đã có nền giấy; không cần áp thêm grading. Nếu tái tạo base từ MOV riêng, chạy prepare_base.py rồi apply_theme_background.py. File gốc không được đóng gói.

Xem output/GHI-CHU-v2.txt về nguồn và giấy phép.
