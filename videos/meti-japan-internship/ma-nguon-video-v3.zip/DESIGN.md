# METI vlog v2 — Nhật ký hành trình nhẹ, hài hòa

## Style Prompt
A contemporary personal travel journal, with the real footage as the main visual. Warm off-white panels, jade typography and sparing terracotta emphasis harmonize with the warm airport lights and natural daylight. Be Vietnam Pro replaces the heavy serif and older sans typography. Rounded lightweight panels, quiet mixed-case branding and restrained shadows feel editorial rather than a lecture deck. Fewer duplicate information blocks preserve faces and locations. Narrative, voice, timing, privacy masks, program focus and photo ending stay unchanged.

## Colors
- #FCFAF5 warm paper background and translucent caption panels
- #17353B dark ink reading text
- #31746A jade headings, active step and progress
- #245F55 deeper jade emphasized heading words
- #A84936 terracotta caption emphasis
- #EDF2ED muted supporting cards
- #FFFFFF image borders and small informational card

## Typography
Be Vietnam Pro regular400, medium500, semibold600 and bold700. Headlines60px semibold, body35px medium, selected phrases bold. Labels/footer28px. Less tracking and no serif display face. Preserve readability on phones, natural wrapping and inline strong inside a span.

## Layout and motion
Same1080×1920 and original time structure, but smaller light surfaces with rounded corners and minimal borders. Real footage remains visible. Active Arrivals guidance is jade on pale green; Domestic/Transit stay quieter. The procedural-card canvas and photo backdrop are warm cream. Small Visit Japan Web image remains secondary. Existing calm finite motion and same scene cuts, no new visual effects or script changes.

## What NOT to Do
- No large solid navy or black blocks in non-filmed sections.
- No heavy serif headlines, neon/cyan/gold mix or all-bold text.
- No change to the confirmed itinerary, narration, program meaning or chronological source order.
- Do not expose any previously masked personal data; recolor opaque masks without removing them.
- No changes to the real colors of passports, faces, airline branding or the supplied webpage illustration.
