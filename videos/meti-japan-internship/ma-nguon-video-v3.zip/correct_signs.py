import json,pathlib
r=pathlib.Path(__file__).parent
voice=['Biển có hai hướng: A rai vồ, Đô mét tích; và In tơ na sờ nồ Tran sơ.','Mình theo hướng A rai vồ, Đô mét tích để nhập cảnh.','In tơ na sờ nồ Tran sơ là hướng nối chuyến quốc tế.']
caps=['Biển có 2 hướng: Arrivals, Domestic và International Transfer.','Mình theo hướng Arrivals, Domestic để nhập cảnh.','International Transfer: hướng nối chuyến quốc tế.']
for name in ['scenes.json','timing.json']:
 a=json.loads((r/name).read_text());s=next(x for x in a if x['kind']=='signs');s.update(title='Hai hướng trên biển.\nTheo Arrivals, Domestic.',em=['Arrivals, Domestic'],highlights=['Arrivals, Domestic','International Transfer'],voice=voice,captions=caps)
 for seg,text in zip(s.get('segments',[]),caps):seg['text']=text
 (r/name).write_text(json.dumps(a,ensure_ascii=False,indent=2))
p=r/'build.py';t=p.read_text();t=t.replace('<div class="guide-row good">ARRIVALS <span>→ Khu vực đến</span></div><div class="guide-row">DOMESTIC <span>· Nội địa</span></div><div class="guide-row">TRANSIT / TRANSFER <span>· Nối chuyến</span></div><div class="route-note">Nhập cảnh tại Narita: theo hướng Arrivals.</div>','<div class="guide-row good">ARRIVALS, DOMESTIC<br><span>Khu vực đến · Nội địa</span></div><div class="guide-row">INTERNATIONAL TRANSFER<br><span>Nối chuyến quốc tế</span></div><div class="route-note">Chặng này: theo hướng Arrivals, Domestic để nhập cảnh.</div>');p.write_text(t)
