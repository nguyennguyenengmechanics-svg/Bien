# Visual identity — METI Japan Internship: nhật ký khởi hành

## Style Prompt
User-filmed vertical travel diary with thoughtful editorial overlays. Preserve chronological order: Tân Sơn Nhất at night, boarding/cabin, Narita in the morning, arrival signs, non-filmed immigration, baggage, non-filmed customs, then bus pickup. Real footage leads; use compact navy caption and title panels, bold amber phrases, teal guidance highlights, clean warm serif headlines. Procedures without footage are explicitly shown as editorial cards, never fake airport footage. The Visit Japan Web section is a small secondary thumbnail derived from the user's screenshot, clearly labelled as an illustration from the supplied image, with Vietnamese explanations outside it. Do not invent website screens or a personal entry QR.

## Colors
- #081C31 navy panel and procedural-card background
- #FFF3DB cream main type
- #FFC76B amber emphasis and timing
- #8FDCDF teal supporting information
- #89E8B7 green Arrivals guidance for this itinerary
- #FFFFFF white screenshot/QR backing

## Typography
DejaVu Serif Bold64–72px short two-line headings. DejaVu Sans regular36px captions, bold meaningful keywords. Data/footer/notes at least28px. Important phrases in bold amber or green, one or two per caption. Wrap full caption in a span to prevent flex fragmentation.

## Layout
1080×1920,30fps; source footage720×1280. Safe padding70px sides,80px top,110px bottom. Small series header, compact chapter title panel, large clear footage area, caption panel near bottom. Guide cards live in the central area only when explaining the signs or non-filmed procedures. Keep faces and actual airport signage unobscured. Website screenshot maintains its original aspect ratio and wording.

## Motion
Deterministic paused GSAP. Calm title reveals, small finite focus highlights, subtle screenshot pan/zoom. Navy wipe around chapter changes covers footage cuts. No fake clicks into a website screen not supplied. No infinite loops, flashes or generated replacement travel shots.

## What NOT to Do
- Do not reorder part2 ahead of part1.
- Do not expose boarding-pass codes, QR/barcodes or personal labels; masks are baked before rendering.
- Do not call Domestic the direction for international entry or Transit the destination for this itinerary. Highlight Arrivals and separately explain the other terms.
- Do not show borrowed immigration/customs footage as the user's own. Clearly mark the missing footage.
- Do not claim the user used Visit Japan Web. Present it as a preparation tip.
- A QR linking to the website is not an entry/customs QR; label it explicitly.
- Do not invent airline timings beyond confirmed00:25 Vietnam and08:00 Japan, immigration wait time, visa or employer.
