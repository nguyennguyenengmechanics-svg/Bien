import sys,pathlib,json
import numpy as np,soundfile as sf
R=pathlib.Path(__file__).parent;s=json.loads((R/'timing.json').read_text());dur=s[-1]['start']+s[-1]['duration'];sr=22050
n=int(dur*sr);music=np.zeros(n,dtype=np.float32);beat=60/92
# Original understated instrumental: warm plucked fifths and a restrained pulse.
notes=[146.832,220,293.665,369.994,130.813,195.998,261.626,329.628,164.814,246.942,329.628,391.995,110,164.814,220,293.665]
for k,on in enumerate(np.arange(0,dur,beat/2)):
 f=notes[(k//16*4+k%4)%16]; length=1.3; t=np.arange(int(length*sr))/sr
 tone=(np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*2*f*t)+.12*np.sin(2*np.pi*3*f*t))*np.exp(-t*5)*np.minimum(t/.012,1)
 a=int(on*sr);b=min(n,a+len(t));music[a:b]+=.025*tone[:b-a]
 if k%2==0:
  t2=np.arange(int(.17*sr))/sr;kick=np.sin(2*np.pi*(58*t2+3*(1-np.exp(-t2*30))))*np.exp(-t2*32);b=min(n,a+len(t2));music[a:b]+=.018*kick[:b-a]
# short tonal cues at chapter transitions, lower than voice
for sc in s[1:]:
 t=np.arange(int(.3*sr))/sr;cue=np.sin(2*np.pi*660*t)*np.sin(np.pi*np.minimum(t/.3,1))**2*np.exp(-t*9)*.025
 a=int(sc['start']*sr);b=min(n,a+len(t));music[a:b]+=cue[:b-a]
fade=np.minimum(np.arange(n)/sr/2,1)*np.minimum((n-np.arange(n))/sr/3,1)
sf.write(R/'composition/assets/music.wav',music*fade,sr)
print('Music duration',dur)
