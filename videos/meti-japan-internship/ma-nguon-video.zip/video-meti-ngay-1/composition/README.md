# Nhật ký METI — Tân Sơn Nhất đến Narita

Video dọc 1080×1920, 30 fps, khoảng 1 phút 31 giây. Cảnh quay thật của người dùng; lời Việt tổng hợp, phụ đề nhấn từ khóa, thẻ thủ tục không ghi hình, Visit Japan Web nhỏ và ảnh kết ngày đầu tiên.

## Render lại

Trong thư mục composition với HyperFrames 0.9.0 và FFmpeg:

```sh
npx hyperframes check --samples 15
npx hyperframes render . --output meti-japan-internship-ngay-1.mp4 --fps 30 --quality high
```

Nếu dùng Chromium hệ thống, đặt HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium. Tài nguyên phát lại có trong assets, gồm base.mp4 đã che mã và bỏ âm thanh gốc. Không cần tải mô hình giọng để render lại.

build.py ở thư mục gốc đọc timing.json và tạo HTML/SRT/lời dẫn. Video nền đã được cân sáng sẵn bằng FFmpeg; không áp thêm một lớp grading khi render lại. Các thông số lưu trong output/color-bake.json.

prepare_base.py và edit-decisions.json lưu quyết định dựng. File gốc của người dùng không đóng gói; chỉ cần chúng nếu muốn dựng lại phần video nền. Xem GHI-CHU.txt trong output về nguồn, giả thiết và quyền tài nguyên.
