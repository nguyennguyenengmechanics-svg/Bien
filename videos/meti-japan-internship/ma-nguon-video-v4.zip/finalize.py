from pathlib import Path
import subprocess,shutil
r=Path(__file__).parent;o=r/'output';main=o/'meti-japan-internship-ngay-1-v4.mp4';raw=o/'render-before-final.mp4';intro=o/'intro-final.mp4'
if not raw.exists():main.rename(raw)
# Only the first six seconds are replaced by the contrast-polished render.
# Re-encode at a bounded bitrate for GitHub's 100-MiB per-file limit.
f='[0:v]trim=end_frame=180,setpts=PTS-STARTPTS[i];[1:v]trim=start_frame=180,setpts=PTS-STARTPTS[r];[i][r]concat=n=2:v=1:a=0[v]'
subprocess.run(['ffmpeg','-v','error','-y','-threads','3','-i',str(intro),'-threads','3','-i',str(raw),'-filter_complex',f,'-map','[v]','-map','1:a','-af','loudnorm=I=-16:TP=-1.5:LRA=9','-c:v','libx264','-preset','fast','-crf','18','-maxrate','8M','-bufsize','16M','-threads','4','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:a','aac','-b:a','192k','-ar','48000','-t','91.466667','-movflags','+faststart',str(main)],check=True)
clean=o/'meti-japan-internship-ngay-1-v4-chi-loi-dan.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-i',str(main),'-i',str(r/'composition/assets/narration.wav'),'-map','0:v','-map','1:a','-c:v','copy','-af','loudnorm=I=-16:TP=-1.5:LRA=9,apad','-c:a','aac','-b:a','192k','-ar','48000','-t','91.466667','-movflags','+faststart',str(clean)],check=True)
assert main.stat().st_size<100*1024**2 and clean.stat().st_size<100*1024**2
print('Final and voice-only exports ready',main.stat().st_size,clean.stat().st_size,flush=True)
