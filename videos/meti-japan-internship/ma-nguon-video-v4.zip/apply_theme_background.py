"""Recolor only opaque editorial/privacy backgrounds; never reveal masked source data."""
from pathlib import Path
import json,subprocess
r=Path(__file__).parent;p=r/'composition/assets/base.mp4';out=r/'assets/base-paper.mp4';out.parent.mkdir(exist_ok=True)
edl=json.load(open(r/'edit-decisions.json'))
filters=["drawbox=x=0:y=0:w=iw:h=370:color=0xFCFAF5:t=fill:enable='lt(n,75)'","drawbox=x=0:y=675:w=iw:h=605:color=0xFCFAF5:t=fill:enable='lt(n,75)'"]
f=0
for x in edl:
 if not x['source']:filters.append(f"drawbox=x=0:y=0:w=iw:h=ih:color=0xFCFAF5:t=fill:enable='between(n,{f},{f+x['frames']-1})'")
 f+=x['frames']
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p),'-vf',','.join(filters),'-an','-c:v','libx264','-preset','fast','-crf','18','-g','30','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True)
out.replace(p)
