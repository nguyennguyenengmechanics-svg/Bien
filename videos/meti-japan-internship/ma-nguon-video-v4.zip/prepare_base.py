import pathlib,json,math,subprocess,concurrent.futures
R=pathlib.Path(__file__).parent;A=R/'composition/assets';tmp=R/'assets/cuts';tmp.mkdir(exist_ok=True)
P1=R/'private-input/part1.mov';P2=R/'private-input/part2.mov'
sc=json.load(open(R/'timing.json'));T=sc[-1]['start']+sc[-1]['duration'];last=0;plans=[]
def add(label,p,ss,ee,n,privacy=False):
 assert n>0;plans.append(dict(index=len(plans),label=label,source=str(p)if p else None,ss=ss,ee=ee,frames=n,privacy=privacy))
for i,s in enumerate(sc):
 end=math.ceil(T*30)if i==len(sc)-1 else round((s['start']+s['duration'])*30);n=end-last;last=end;k=s['kind']
 if k=='intro':
  add('passport-redacted',P1,0,2.50,75,True);add('night-apron',P1,2.533333,6.0,n-75)
 elif k=='meti':
  a=round(n*3.233/9.966);b=round(n*4.267/9.966)
  add('night-apron',P1,6,9.233333,a);add('selfie',P1,9.233333,13.5,b);add('gate',P1,13.5,15.966667,n-a-b)
 elif k=='departure':
  add('jetbridge',P1,15.966667,18.333333,80);add('cabin',P1,18.333333,23.5,n-80)
 elif k=='arrival':
  add('narita-window',P1,27.566667,34.1,n-70);add('arrival-corridor',P1,37.433333,39.733333,70)
 elif k=='signs':
  add('arrivals-sign',P2,0,3.166667,95);add('sign-explainer-card',None,0,0,n-95-87);add('moving-walkway',P2,3.166667,6.066667,87)
 elif k=='immigration':add('immigration-and-vjw-card',None,0,0,n)
 elif k=='baggage':add('baggage-belt',P2,6.066667,11.566667,n)
 elif k=='customs':
  add('customs-not-filmed-card',None,0,0,n-48);add('exit-walk',P2,11.566667,13.166667,48)
 elif k=='friends':add('friends-editorial-photo-background',None,0,0,n)
 elif k=='closing':
  a=min(70,n//3);add('terminal-outside',P2,28.866667,32.2,a);add('airport-bus',P2,32.2,38.133333,n-a)
assert sum(x['frames']for x in plans)==math.ceil(T*30)
(R/'edit-decisions.json').write_text(json.dumps(plans,ensure_ascii=False,indent=2))
def make(x):
 out=tmp/f"{x['index']:02}.mp4";n=x['frames'];cmd=['ffmpeg','-v','error','-y','-threads','2']
 if x['source']:
  cmd+=['-ss',str(x['ss']),'-t',str(x['ee']-x['ss']),'-i',x['source']]
  ratio=(n/30)/(x['ee']-x['ss']);vf=f'setpts={ratio}*(PTS-STARTPTS),fps=30,scale=720:1280:flags=lanczos,setsar=1'
  if x['privacy']:vf+=',drawbox=x=0:y=0:w=iw:h=370:color=0x081C31:t=fill,drawbox=x=0:y=675:w=iw:h=605:color=0x081C31:t=fill'
  vf+=',tpad=stop_mode=clone:stop_duration=0.15'
  cmd+=['-vf',vf]
 else:cmd+=['-f','lavfi','-i','color=c=0x081C31:s=720x1280:r=30']
 cmd+=['-frames:v',str(n),'-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-threads','2',str(out)]
 subprocess.run(cmd,check=True);return x['index']
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
 for i in pool.map(make,plans):print('Prepared clip',i,flush=True)
lst=tmp/'concat.txt';lst.write_text(''.join(f"file '{x['index']:02}.mp4'\n"for x in plans))
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(lst),'-c','copy','-movflags','+faststart',str(A/'base.mp4')],check=True)
raw=A/'base-raw.mp4';(A/'base.mp4').rename(raw)
subprocess.run(['ffmpeg','-v','error','-y','-threads','3','-i',str(raw),'-vf','eq=contrast=1.025:brightness=0.003:gamma=1.012:saturation=1.0','-an','-c:v','libx264','-preset','fast','-crf','18','-g','30','-keyint_min','30','-pix_fmt','yuv420p','-threads','3','-movflags','+faststart',str(A/'base.mp4')],check=True)
raw.unlink()
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(A/'base.mp4')]))
assert int(d['streams'][0]['nb_frames'])==math.ceil(T*30)
print('Base ready:',math.ceil(T*30),'frames; privacy masks baked; original audio removed.',flush=True)
