# METI vlog v4 — Mở đầu động, hình quay thoáng

Video dọc1080×1920,30fps,91,45giây. Toàn bộ tài nguyên đã xử lý để render có trong assets. Không cần tệp MOV/HEIC gốc hoặc mô hình TTS để render.

Tại thư mục composition:

```sh
npx hyperframes check --samples 13
npx hyperframes render . --output meti-japan-internship-ngay-1-v4.mp4 --fps 30 --quality high --workers 3
```

Nếu dùng Chromium hệ thống, đặt HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium.

build.py ở gốc đọc theme.css và timing.json để tái tạo HTML, phụ đề, lời dẫn. music.py tái tạo nhạc gốc tạm120BPM cho bản xem thử, không phải nhạc trend. Đặt data-volume="0" cho audio#music nếu muốn render chỉ giọng. Bản chỉ lời dẫn được xuất sẵn trong thư mục GitHub.

prepare_hook.py là ghi chép tái dựng mở đầu từ video nền đã xử lý của bản v3; cần đường dẫn v3-base bên ngoài gói nếu chạy. prepare_base.py/apply_theme_background.py cần đầu vào riêng của người dùng. Không cần chạy các bước này khi dùng assets/base.mp4 đi kèm. Xem DESIGN.md, output/GHI-CHU-v4.txt và NHAC-TIKTOK-v4.md.
