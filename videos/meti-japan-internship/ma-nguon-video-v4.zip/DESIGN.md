# V4 — Hình quay là trọng tâm

## Style
Nhật ký cá nhân tham gia METI Japan Internship. Cảnh quay toàn màn hình, chữ gọn ở mép, phần giữa để thoáng cho người và cảnh. Chỉ dùng nền giấy cho đoạn giải thích không có hình quay. Giữ hai hướng trên biển: Arrivals, Domestic / International Transfer; Visit Japan Web là thông tin phụ.

## Colors
- #FCFAF5: nền giấy cho phần không ghi hình.
- #17353B: chữ trên giấy.
- #31746A và #245F55: nhấn xanh ngọc trên giấy.
- #FFFFFF: chữ trên cảnh quay, bóng tối nhẹ.
- #A84936: từ khóa trong thẻ giải thích.
Chữ trên footage không có bảng nền kín; chỉ có lớp chuyển tối trong suốt ở mép trên/dưới để giữ độ đọc.

## Typography
Be Vietnam Pro 400/500/600/700 (SIL OFL). Tiêu đề cảnh quay 51px; mở đầu 66/88px. Phụ đề 33px; nhãn và thông tin phụ tối thiểu 28px. Thẻ giấy 32px/51px. Tên chương trình xuất hiện sớm, không thêm yếu tố du lịch lấn át METI.

## Motion and edit
Sáu giây mở đầu có bốn cảnh ngắn 1,5 giây từ part1 đã xử lý; sau đó tiếp tục trình tự đã duyệt. Không dùng cảnh hộ chiếu phải che phần lớn hình làm mở đầu. Chữ mở đầu lên theo hai nhịp, tiếp theo tên chương trình và đường bay SGN → NRT trong khoảng 3 giây đầu. GSAP hữu hạn, timeline paused, có chuyển cảnh. Đoạn hướng dẫn biển chỉ xuất hiện đầy đủ khi video nền là thẻ giấy, để người xem thấy biển thật khi footage chạy.
Nhạc xem thử là bản gốc tạo bằng code 120 BPM và hạ âm dưới giọng. Không phải nhạc trend đã xác minh. Bản riêng chỉ có lời dẫn được tạo để ghép âm thanh TikTok sau.

## Avoid
- Không khối chữ đặc che mặt người, máy bay, biển hoặc hành lý.
- Không làm lộ thông tin cá nhân đã che; không đóng gói MOV/HEIC/RAR gốc.
- Không thay lời đọc/nhập cảnh/giờ bay đã duyệt.
- Không tự gắn nhãn nhạc thịnh hành khi chưa kiểm tra nguồn hiện tại.
