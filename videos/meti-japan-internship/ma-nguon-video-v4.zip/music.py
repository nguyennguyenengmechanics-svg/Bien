# Original 120-BPM travel-bed, temporary preview only; not claimed to be trending.
from pathlib import Path
import json,numpy as np,soundfile as sf
r=Path(__file__).parent;sc=json.loads((r/'timing.json').read_text());dur=sc[-1]['start']+sc[-1]['duration'];sr=22050;n=round(sr*dur);out=np.zeros(n,dtype=np.float32);rng=np.random.default_rng(41)
def add(on,x,g=1):
 a=round(on*sr);b=min(n,a+len(x))
 if b>a:out[a:b]+=g*x[:b-a]
def tone(f,seconds=.7):
 t=np.arange(round(seconds*sr))/sr
 return (np.sin(2*np.pi*f*t)+.22*np.sin(4*np.pi*f*t))*np.exp(-t*6)*np.minimum(t/.006,1)
chords=[[261.626,329.628,391.995],[220,261.626,329.628],[174.614,220,261.626],[195.998,246.942,293.665]]
for k,on in enumerate(np.arange(.1,dur,.25)):
 c=chords[(k//32)%4];level=.039 if on<6 else .025
 add(on,tone(c[[0,1,2,1,2,1,0,1][k%8]]*2,.65),level)
 if k%2==0:
  t=np.arange(round(.22*sr))/sr;kick=np.sin(2*np.pi*(52*t+2.8*(1-np.exp(-t*32))))*np.exp(-t*26);add(on,kick,.065 if on<6 else .035)
  if k%4==2:
   t=np.arange(round(.11*sr))/sr;noise=rng.standard_normal(len(t));noise=np.concatenate(([0],np.diff(noise)));add(on,noise*np.exp(-t*43),.012)
 t=np.arange(round(.045*sr))/sr;add(on,rng.standard_normal(len(t))*np.exp(-t*100),.007)
 if k%4==0:add(on,tone(c[0]/2,1),.028)
# Gentle sidechain under the existing Vietnamese narration.
env=np.ones(n,np.float32)
for scene in sc:
 for seg in scene['segments']:
  a=max(0,round((seg['start']-.10)*sr));b=min(n,round((seg['start']+seg['duration']+.12)*sr));env[a:b]=.42
fade=np.minimum(np.arange(n)/sr/.07,1)*np.minimum((n-np.arange(n))/sr/1.5,1)
sf.write(r/'composition/assets/music.wav',out*env*fade,sr)
print('Original temporary preview music: 120 BPM; ducked under voice; peak',float(np.max(np.abs(out*env*fade))))
