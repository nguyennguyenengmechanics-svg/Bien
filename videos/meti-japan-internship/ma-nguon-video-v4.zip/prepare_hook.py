from pathlib import Path
import subprocess
r=Path(__file__).parent
src=Path('/workspace/meti-narita-v3/composition/assets/base.mp4')
# All shots come from the existing sanitized derivative. Four brief part-1 previews,
# then the approved chronology resumes at 6 seconds, with identical timing thereafter.
f='[0:v]split=5[a][b][c][d][e];[a]trim=start_frame=75:end_frame=120,setpts=PTS-STARTPTS[a1];[b]trim=start_frame=426:end_frame=471,setpts=PTS-STARTPTS[b1];[c]trim=start_frame=303:end_frame=348,setpts=PTS-STARTPTS[c1];[d]trim=start_frame=120:end_frame=165,setpts=PTS-STARTPTS[d1];[e]trim=start_frame=180,setpts=PTS-STARTPTS[e1];[a1][b1][c1][d1][e1]concat=n=5:v=1:a=0[v]'
subprocess.run(['ffmpeg','-v','error','-y','-threads','3','-i',str(src),'-filter_complex',f,'-map','[v]','-an','-c:v','libx264','-preset','fast','-crf','18','-g','30','-pix_fmt','yuv420p','-threads','3','-movflags','+faststart',str(r/'composition/assets/base.mp4')],check=True)
print('Intro: 4 x 1.5s shots; masked passport opener removed; rest unchanged')
