# 9 cơ chế hỏng trong thiết kế cơ khí

Nguồn chỉnh sửa: index.html. Thiết kế: DESIGN.md. Âm thanh và font được đóng gói trong assets; không cần API key để render lại.

Dùng Node.js 22+, Chromium và FFmpeg:

```bash
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 render --output final.mp4 --fps 30 --quality high --workers 3
```

Bản dựng có lời Việt tổng hợp và nhạc tự phối. Mỗi hình cơ khí là sơ đồ nguyên lý, không phải mô phỏng. Xem GHI-CHU.txt đi kèm bộ xuất để biết nguồn nội dung và attribution.
