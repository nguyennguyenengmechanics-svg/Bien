from pathlib import Path
import json,math
import numpy as np,soundfile as sf,sherpa_onnx
R=Path(__file__).parent;assets=R/'composition/assets';chunks=R/'voice-segments';chunks.mkdir(exist_ok=True)
model=Path('/workspace/mui-si-video/vits-piper-vi_VN-vais1000-medium')
cfg=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(model/'vi_VN-vais1000-medium.onnx'),tokens=str(model/'tokens.txt'),data_dir=str(model/'espeak-ng-data')),num_threads=3,debug=False))
tts=sherpa_onnx.OfflineTts(cfg);scenes=json.loads((R/'scenes.json').read_text());sr=22050;pos=0;allchunks=[]
for i,s in enumerate(scenes):
 s['start']=round(pos,3);pos+=1.0;s['segments']=[]
 for j,(voice,cap) in enumerate(zip(s['voice'],s['captions'])):
  f=chunks/f'{i:02}-{j:02}.wav'
  if f.exists():samples,sr=sf.read(f,dtype='float32')
  else:
   a=tts.generate(voice,sid=0,speed=.96);sr=a.sample_rate;samples=a.samples;sf.write(f,samples,sr)
  dur=len(samples)/sr;s['segments'].append(dict(start=round(pos,3),duration=round(dur,3),text=cap,audio=f'voice-segments/{f.name}'));allchunks.append((pos,samples));pos+=dur+.42
 s['duration']=round(pos+.6-s['start'],3);pos=s['start']+s['duration'];print(i+1,round(s['duration'],1),'total',round(pos,1),flush=True)
total=math.ceil(pos*30)/30;scenes[-1]['duration']=round(total-scenes[-1]['start'],3)
narr=np.zeros(round(total*sr),np.float32)
for start,samples in allchunks:
 k=round(start*sr);narr[k:k+len(samples)]+=samples
sf.write(assets/'narration-raw.wav',narr,sr)
# Original quiet instrumental, deterministic pentatonic arpeggios and warm pads.
msr=44100;music=np.zeros((math.ceil(total*msr),2),np.float32);beat=60/84
chords=[[48,55,60,64],[45,52,57,60],[41,48,53,57],[43,50,55,59]]
for bar in range(math.ceil(total/(beat*4))):
 chord=chords[bar%4];base=bar*4*beat
 for j,midi in enumerate(chord):
  t=np.arange(int(msr*beat*4))/msr;f=440*2**((midi-69)/12);tone=np.sin(2*np.pi*f*t)*np.sin(np.pi*t/(beat*4))**2*.012
  k=round(base*msr);n=min(len(tone),len(music)-k)
  if n>0:music[k:k+n,:]+=tone[:n,None]*np.array([.85,1])
 for j in range(8):
  t=np.arange(int(msr*1.7))/msr;f=440*2**((chord[j%4]+12-69)/12)
  tone=(np.sin(2*np.pi*f*t)+.22*np.sin(4*np.pi*f*t))*(1-np.exp(-t*75))*np.exp(-t*3)*.018
  k=round((base+j*beat/2)*msr);n=min(len(tone),len(music)-k)
  if n>0:music[k:k+n,:]+=tone[:n,None]*np.array([1,.7] if j%2 else [.7,1])
t=np.arange(len(music))/msr;music*=np.minimum(t/3,1)[:,None]*np.clip((total-t)/4,0,1)[:,None]
sf.write(assets/'music.wav',music,msr)
(R/'timing.json').write_text(json.dumps(scenes,ensure_ascii=False,indent=2));print('TOTAL',total,flush=True)
