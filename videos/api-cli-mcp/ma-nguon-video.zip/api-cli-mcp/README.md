# API · CLI · MCP — Chọn đúng cách kết nối AI

Video học thuật tiếng Việt, 10 cảnh, 1080×1920 / 30 fps, khoảng 4 phút 16 giây. Sơ đồ SVG mới và chữ nhấn màu theo mẫu video-hoc-thuat.

## Render lại

Cài Node.js 22 trở lên, FFmpeg và Chrome/Chromium. Cài HyperFrames `npm install --save-dev hyperframes@0.8.221`. Có thể mở trực tiếp thư mục `composition` bằng HyperFrames.

```sh
npx hyperframes check composition --samples 15
npx hyperframes render composition --output output/api-cli-mcp.mp4 --fps 30 --quality high --workers 3
```

Khi cần, đặt `HYPERFRAMES_BROWSER_PATH` tới executable Chrome có thật trên máy. Không sao chép đường dẫn cache từ máy dựng cũ.

HTML, SVG, GSAP, font và hai tệp âm thanh cuối đều có sẵn. Không cần API key hay mô hình TTS để render lại.

## Sửa nội dung

- `project.json`: tiêu đề và thông tin dự án.
- `scenes.json`: kịch bản và phụ đề theo đoạn.
- `timing.json`: thời lượng thực của giọng đọc đã dùng, gồm 40 đoạn. Thay giọng đọc phải tính lại thời gian.
- `diagrams.py`: sơ đồ SVG và hoạt họa theo đoạn.
- `build.py`: tạo `composition/index.html`, phụ đề SRT và lời dẫn; cần Python 3 và Pillow (`pip install Pillow`). Chạy `python build.py` sau khi sửa bố cục hoặc sơ đồ.
- `make_audio.py`: mã tạo giọng và nhạc; đường dẫn mô hình phải đổi theo máy. Có thể dùng engine giọng Việt khác; đo lại từng đoạn và cập nhật timing. Mô hình TTS không được đóng gói.
- `DESIGN.md`: nhận diện hình ảnh của mẫu đã chọn.

`GHI-CHU.txt` trong bộ đầu ra nêu nguồn, giới hạn, các hiệu chỉnh nội dung và giấy phép. Không có bản ghi gốc của người dùng trong gói nguồn.

Âm thanh trong gói được nén FLAC không mất dữ liệu. Nếu tạo lại giọng bằng make_audio.py, chuẩn hóa narration-raw.wav tới khoảng −16 LUFS rồi chuyển narration.wav và music.wav sang FLAC bằng FFmpeg trước khi chạy build.py.
