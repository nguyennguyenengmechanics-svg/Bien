# Topic-specific SVGs. All diagrams are conceptual, not measurements.
BLUE='#0A527B'; ORANGE='#B83B16'; GREEN='#2D6842'; INK='#142D38'; CREAM='#F1F0E4'; LIGHT='#E5E7DE'
def txt(x,y,label,size=32,color=INK,bold=False):
 return text(x,y,label,max(31,size),color,bold=bold)
def box(x,y,w,h,title,sub='',color=BLUE):
 from PIL import ImageFont
 title_size=36
 while title_size>31 and ImageFont.truetype(str(P/'assets/DejaVuSans-Bold.ttf'),title_size).getlength(title)>w-26:title_size-=1
 title_y=y+(h*.35 if sub else h*.57)
 result=rect(x,y,w,h,'#FFFFFF',color,18)+txt(x+w/2,title_y,title,title_size,color,True)
 if sub:
  font=ImageFont.truetype(str(P/'assets/DejaVuSans.ttf'),31);lines=[];current=''
  for word in sub.split():
   candidate=(current+' '+word).strip()
   if font.getlength(candidate)>w-26 and current:lines.append(current);current=word
   else:current=candidate
  if current:lines.append(current)
  for k,t in enumerate(lines):result+=txt(x+w/2,y+h*(.70 if len(lines)==1 else .65)+k*34,t,31,INK)
 return result
def group(n,body):return f'<g class="beat{n}">{body}</g>'
def edge(x1,y1,x2,y2,i,color=BLUE):return line(x1,y1,x2,y2,color,8,f'marker-end="url(#m{i}{"b" if color==BLUE else "o"})"')
def dots(x,y):return f'<circle class="traveller" cx="{x}" cy="{y}" r="10" fill="{ORANGE}"/>'
def svg(kind,i):
 defs=f'<defs><marker id="m{i}b" markerWidth="12" markerHeight="12" refX="10" refY="6" orient="auto" markerUnits="userSpaceOnUse"><path d="M1 1L11 6L1 11Z" fill="{BLUE}"/></marker><marker id="m{i}o" markerWidth="12" markerHeight="12" refX="10" refY="6" orient="auto" markerUnits="userSpaceOnUse"><path d="M1 1L11 6L1 11Z" fill="{ORANGE}"/></marker></defs>'
 b=''
 if kind=='overview':
  b+=group(1,box(320,35,260,100,'ỨNG DỤNG AI','Hiểu mục tiêu')+edge(450,135,450,180,i)+path('M160 215 V180 H740 V215',BLUE,8))
  for n,x,title,sub,c in [(2,40,'API','Giao diện phần mềm',BLUE),(3,330,'CLI','Giao diện dòng lệnh',ORANGE),(4,620,'MCP','Chuẩn kết nối AI',GREEN)]:
   b+=group(n,box(x,220,240,145,title,sub,c)+edge(x+120,365,x+120,440,i,ORANGE)+path(f'M{x+120} 440 H450 V470',ORANGE,7))
  b+=group(4,box(210,475,480,105,'DỮ LIỆU · DỊCH VỤ','Đọc · xử lý · tạo kết quả',BLUE))
 elif kind=='api':
  b+=group(1,box(45,50,310,115,'CHƯƠNG TRÌNH','Gửi yêu cầu',BLUE)+box(545,50,310,115,'DỊCH VỤ WEB','Xử lý · phản hồi',GREEN))
  b+=group(2,edge(355,95,535,95,i)+txt(450,70,'Yêu cầu',29,BLUE,True)+edge(545,145,365,145,i,ORANGE)+txt(450,191,'Kết quả',29,ORANGE,True))
  b+=group(2,rect(100,245,700,155,CREAM,'none',16)+txt(450,293,'Địa chỉ + thao tác + tham số',35,BLUE,True)+txt(450,351,'GET /report?date=2026-11-14',30,INK))
  b+=group(3,box(85,445,340,110,'XÁC THỰC','Khóa · OAuth · cách khác',ORANGE))
  b+=group(4,box(475,445,340,110,'KẾT QUẢ','Dữ liệu · tệp · lỗi',GREEN))
  b+=txt(450,602,'Ví dụ dịch vụ web; API còn có dạng cục bộ.',28,INK)
 elif kind=='cli':
  b+=group(1,rect(45,42,810,158,INK,'none',18)+txt(450,94,'TERMINAL',29,'#FFFFFF',True)+txt(450,152,'$ report export --today',38,'#FFFFFF',True))
  b+=txt(450,238,'Lệnh giả định để minh họa cơ chế',28,ORANGE)
  b+=group(2,box(40,285,235,115,'01 · Cấu hình','Đọc tham số',BLUE)+edge(280,342,325,342,i)+box(335,285,235,115,'02 · Xử lý','Lấy dữ liệu',BLUE)+edge(575,342,620,342,i,ORANGE)+box(630,285,230,115,'03 · Lưu tệp','Xuất báo cáo',ORANGE))
  b+=group(3,box(100,470,315,100,'API MẠNG','Kết nối dịch vụ',BLUE)+box(485,470,315,100,'TỆP CỤC BỘ','Xử lý trên máy',GREEN))
  b+=group(4,txt(450,610,'Luôn kiểm tra đầu ra và mã thoát.',30,INK,True))
 elif kind=='mcp':
  b+=group(1,box(40,52,280,125,'ỨNG DỤNG AI','Host + MCP client',BLUE)+box(580,52,280,125,'MCP SERVER','Cung cấp khả năng',GREEN))
  b+=group(2,edge(325,90,570,90,i)+txt(450,65,'tools/list',29,BLUE,True)+edge(325,155,570,155,i,ORANGE)+txt(450,202,'tools/call',29,ORANGE,True))
  b+=group(2,box(170,260,560,100,'THAM SỐ CÓ CẤU TRÚC','Tên công cụ + dữ liệu đầu vào',BLUE))
  b+=group(3,path('M800 177 V405 H210 V445 M720 405 V445',BLUE,8)+box(65,455,310,115,'DỊCH VỤ','API được phép',BLUE)+box(545,455,310,115,'TỆP / MÃ LỆNH','Tài nguyên được phép',ORANGE))
  b+=group(4,txt(450,610,'Máy chủ có thể ở máy bạn hoặc từ xa.',28,INK))
 elif kind=='compare':
  for n,y,t,sub,c in [(1,40,'API · TÍCH HỢP TRỰC TIẾP','Biết rõ dữ liệu và định dạng cần lấy',BLUE),(2,205,'CLI · QUY TRÌNH LẶP LẠI','Lấy báo cáo → lưu tệp mỗi sáng',ORANGE),(3,370,'MCP · KHÁM PHÁ QUA AI','Hỏi tiếp → chọn công cụ → phân tích',GREEN)]:
   b+=group(n,rect(45,y,810,140,'#FFFFFF',c,18)+txt(450,y+55,t,35,c,True)+txt(450,y+107,sub,31,INK))
  b+=group(4,txt(450,580,'Có thể phối hợp trong cùng một quy trình.',30,INK,True))
 elif kind=='context':
  b+=group(1,txt(450,72,'BÊN TRONG NGỮ CẢNH',37,BLUE,True))
  for n,(x,w,title,sub,c) in enumerate([(45,180,'Chỉ dẫn','Quy tắc',BLUE),(225,210,'Công cụ','Mô tả',ORANGE),(435,215,'Hội thoại','Yêu cầu',GREEN),(650,205,'Kết quả','Dữ liệu',INK)]):
   b+=group(1,rect(x,125,w,158,c,'#FFFFFF',0)+txt(x+w/2,188,title,30,'#FFFFFF',True)+txt(x+w/2,240,sub,28,'#FFFFFF'))
  b+=txt(450,330,'Sơ đồ thành phần, không biểu diễn số token.',28,INK)
  b+=group(2,box(50,385,365,135,'NẠP SẴN','Nhiều mô tả có thể tốn chỗ',ORANGE))
  b+=group(3,box(485,385,365,135,'THEO NHU CẦU','Chỉ tải công cụ được chọn',GREEN))
  b+=group(4,txt(450,590,'CLI cũng có câu lệnh và kết quả AI phải đọc.',30,BLUE,True))
 elif kind=='optimize':
  b+=group(1,box(45,45,330,115,'ĐẦU VÀO','Đúng công cụ cần dùng',BLUE))
  b+=group(2,edge(380,103,520,103,i)+box(530,45,325,115,'KẾT QUẢ GỌN','Đúng trường · đúng số dòng',ORANGE))
  b+=group(2,rect(65,220,770,95,CREAM,'none',15)+txt(450,280,'1000 dòng → lọc → 10 dòng cần thiết',34,BLUE,True))
  b+=group(2,txt(450,355,'Số dòng giả định; không phải số đo hiệu năng.',28,INK))
  b+=group(3,box(40,415,250,115,'TOKEN','Lượng nội dung',BLUE)+box(325,415,250,115,'THỜI GIAN','Độ trễ thực tế',ORANGE)+box(610,415,250,115,'THỬ LẠI','Độ ổn định',GREEN))
  b+=group(4,txt(450,600,'Không có hệ số tiết kiệm cố định cho mọi việc.',30,INK,True))
 elif kind=='choice':
  rows=[(1,35,'01 · MÔI TRƯỜNG','Không chạy lệnh?','Kết nối được hỗ trợ',BLUE),(2,185,'02 · LẶP LẠI','Quy trình đã rõ?','CLI / tập lệnh',ORANGE),(3,335,'03 · KIỂM SOÁT','Tự tích hợp sâu?','API trực tiếp',BLUE),(4,485,'KHÁM PHÁ','Phối hợp công cụ?','Cân nhắc MCP',GREEN)]
  for n,y,label,question,result,c in rows:
   b+=group(n,rect(35,y,830,115,'#FFFFFF',c,16)+text(65,y+37,label,28,c,anchor='start',bold=True)+text(65,y+82,question,31,INK,anchor='start')+edge(410,y+65,470,y+65,i,c if c==BLUE else ORANGE)+txt(665,y+76,result,31,c,True))
 elif kind=='names':
  for n,y,title,sub,c in [(1,45,'SKILL','Hướng dẫn + tài nguyên + quy trình',BLUE),(2,215,'CONNECTOR','Kết nối tới dữ liệu / dịch vụ',ORANGE),(3,385,'PLUGIN','Gói mở rộng: có thể chứa skill / công cụ',GREEN)]:
   b+=group(n,rect(45,y,810,140,'#FFFFFF',c,18)+txt(450,y+57,title,38,c,True)+txt(450,y+112,sub,31,INK))
  b+=group(4,txt(450,594,'MCP là giao thức, không phải mọi tên menu.',30,INK,True))
 elif kind=='summary':
  b+=group(1,box(45,45,810,105,'ĐÚNG QUYỀN · ĐÚNG TÀI KHOẢN','Chỉ cấp phạm vi cần dùng',GREEN))
  b+=group(2,box(45,195,810,105,'TÁCH CẤU HÌNH DỰ ÁN','Phạm vi cài đặt ≠ quyền truy cập',ORANGE))
  b+=group(3,box(45,350,245,110,'API','Tích hợp',BLUE)+box(330,350,245,110,'CLI','Câu lệnh',ORANGE)+box(615,350,245,110,'MCP','Chuẩn kết nối',GREEN))
  b+=group(4,rect(70,515,760,85,CREAM,'none',12)+txt(450,568,'CHỌN THEO VIỆC · ĐO TRƯỚC KHI MỞ RỘNG',30,INK,True))
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 640" role="img" aria-label="Sơ đồ {kind}">{defs}{b}</svg>'
def animate(scene,selector):
 out=[]
 for n in range(1,5):
  start=scene['start']+.9 if n==1 else scene['segments'][n-1]['start']-.1
  if scene['diagram']=='overview' and n>1:start=scene['segments'][1]['start']+(n-2)*1.2
  out.append(f'tl.from("#{selector} .beat{n}",{{opacity:0,y:12,duration:.5,ease:"power2.out"}},{start});')
 return out
