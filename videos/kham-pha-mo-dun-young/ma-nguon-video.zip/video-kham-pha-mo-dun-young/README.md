# Khám phá mô đun Young: hiểu độ cứng vật liệu

Nguồn chỉnh sửa: index.html. Font, giọng đọc và nhạc đi kèm assets. Cần Node.js 22+, Chromium, FFmpeg; không cần API key để xuất lại.

```bash
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 render --output final.mp4 --fps 30 --quality high --workers 3
```

Đọc GHI-CHU.txt về giả thiết, nguồn và attribution. Các số trong ví dụ tính E là giả định minh họa, không phải dữ liệu đo. Hình nguyên tử, đồ thị và độ dãn là minh họa định tính có phóng đại.
