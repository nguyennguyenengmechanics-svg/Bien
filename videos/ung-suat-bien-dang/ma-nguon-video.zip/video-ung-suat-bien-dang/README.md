# Ứng suất, biến dạng và đánh giá độ bền

index.html là nguồn chỉnh sửa, DESIGN.md quy định hình thức. Font, giọng đọc và nhạc kèm trong assets. Cần Node.js 22+, Chromium, FFmpeg; không cần API key để xuất lại.

```bash
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 check
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npx --yes hyperframes@0.9.0 render --output final.mp4 --fps 30 --quality high --workers 3
```

Đọc GHI-CHU.txt về giả thiết kỹ thuật, nguồn và attribution. Sơ đồ và đồ thị minh họa không phải kết quả mô phỏng hay số liệu thử nghiệm.
